package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@TableName("im_friendship_group_member")
public class FriendshipGroupMemberEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @TableField("group_id")
    private Long groupId;

    @TableField("to_id")
    private Long toId;

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }
    public Long getToId() {
        return toId;
    }

    public void setToId(Long toId) {
        this.toId = toId;
    }

    @Override
    public String toString() {
        return "FriendshipGroupMemberEntity{" +
            "groupId=" + groupId +
            ", toId=" + toId +
        "}";
    }
}
