package com.wb.imall.service.service.Impl;

import com.wb.imall.service.entity.GroupMemberEntity;
import com.wb.imall.service.mapper.GroupMemberDao;
import com.wb.imall.service.service.GroupMemberService;
import com.wb.imall.common.base.BaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@Service
public class GroupMemberServiceImpl extends BaseServiceImpl<GroupMemberDao, GroupMemberEntity> implements GroupMemberService {

}
