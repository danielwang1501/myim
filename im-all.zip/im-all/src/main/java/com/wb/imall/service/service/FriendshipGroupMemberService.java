package com.wb.imall.service.service;

import com.wb.imall.service.entity.FriendshipGroupMemberEntity;
import com.wb.imall.common.base.BaseService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
public interface FriendshipGroupMemberService extends BaseService<FriendshipGroupMemberEntity> {

}
