package com.wb.imall.service.service.Impl;

import com.wb.imall.service.entity.GroupEntity;
import com.wb.imall.service.mapper.GroupDao;
import com.wb.imall.service.service.GroupService;
import com.wb.imall.common.base.BaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@Service
public class GroupServiceImpl extends BaseServiceImpl<GroupDao, GroupEntity> implements GroupService {

}
