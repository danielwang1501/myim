package com.wb.imall.codec.pojo;

import lombok.Data;

@Data
public class MessageHeader {
    private int command;
    private int version;
    private int clientType;
    private int messageType;
    private int appId;
    private String imei;
}
