package com.wb.imall.codec.config;

import lombok.Data;

@Data
public class IMConfig {
    private TcpConfig im;

    @Data
    public static class TcpConfig {
        private Integer tcpPort;
        private Integer webSocketPort;
        private Integer bossThreadSize;
        private Integer workThreadSize;
    }
}
