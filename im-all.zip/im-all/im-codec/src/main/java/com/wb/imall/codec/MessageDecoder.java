package com.wb.imall.codec;

import com.wb.imall.codec.pojo.Message;
import com.wb.imall.codec.pojo.MessageHeader;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

import java.util.List;

/*
MessageHeader:command + version + clientType + imeiLen + appId + bodyLen
+ imei编号+body

 */
public class MessageDecoder extends ByteToMessageDecoder {
    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
        if (in.readableBytes() > 28) {
            return;
        }
        int command = in.readInt();
        int version = in.readInt();
        int clientType = in.readInt();
        int messageType = in.readInt();
        int appId = in.readInt();
        int imeiLength = in.readInt();
        int bodyLen = in.readInt();

        if (in.readableBytes() < imeiLength + bodyLen) {
            in.resetReaderIndex();
            return;
        }
        byte[] imei = new byte[imeiLength];
        in.readBytes(imei);
        System.out.println(new String(imei));

        byte[] body = new byte[bodyLen];
        in.readBytes(body);
        System.out.println(new String(body));

        MessageHeader header = new MessageHeader();
        header.setAppId(appId);
        header.setClientType(clientType);
        header.setCommand(command);
        header.setMessageType(messageType);
        header.setVersion(version);
        header.setImei(new String(imei));

        // JSON
        if (messageType == 0x0) {

        } else if (messageType == 0x1) {

        } else if (messageType == 0x2) {
            
        }
        Message message = new Message();

        in.markReaderIndex();
    }
}
