package com.wb.imall.codec.pojo;

import lombok.Data;

@Data
public class Message {
    private MessageHeader header;
    private Object messagePack;
}
