package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

@Data
public class GetGroupInfoReq extends AbstractRequest {
    private Long id;
}
