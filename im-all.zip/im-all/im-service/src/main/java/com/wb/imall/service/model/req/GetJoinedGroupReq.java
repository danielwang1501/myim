package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

import java.util.Set;

@Data
public class GetJoinedGroupReq extends AbstractRequest {
    private Long memberId;
    private Set<Integer> groupTypes;
}
