package com.wb.imall.service.model.resp;

import lombok.Data;

@Data
public class AddMemberResp {
    private Long memberId;
    private Integer result;
    private String message;
}
