package com.wb.imall.service.model.resp;

import lombok.Data;

@Data
public class CheckBlackResp {
    private Long toId;
    private Integer blackRelationType;
}
