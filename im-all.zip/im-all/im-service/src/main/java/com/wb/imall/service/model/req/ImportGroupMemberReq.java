package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

import java.util.List;

@Data
public class ImportGroupMemberReq extends AbstractRequest {
    private Long groupId;
    private List<GroupMemberDto> groupMemberList;
}
