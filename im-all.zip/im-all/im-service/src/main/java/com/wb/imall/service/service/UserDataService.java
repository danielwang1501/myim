package com.wb.imall.service.service;

import com.wb.imall.common.R;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.entity.UserDataEntity;
import com.wb.imall.service.model.req.ImportUserReq;
import com.wb.imall.service.model.req.UserDto;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-05
 */
public interface UserDataService extends BaseService<UserDataEntity> {
    R importUser(ImportUserReq req, Integer appId);

    List<UserDto> queryList(Set<Long> ids);

    boolean update(UserDto userDto);
}
