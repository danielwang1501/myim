package com.wb.imall.service.model.req;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Setter
@Getter
@ToString
public class ImportUserReq {
    private List<UserDto> userList;
}
