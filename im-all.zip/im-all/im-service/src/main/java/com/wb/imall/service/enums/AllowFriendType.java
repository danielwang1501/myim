package com.wb.imall.service.enums;

public enum AllowFriendType {

    NO_NEED(1),
    NEED(2),
    ALL(3),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    AllowFriendType(int code) {
        this.code = code;
    }
}
