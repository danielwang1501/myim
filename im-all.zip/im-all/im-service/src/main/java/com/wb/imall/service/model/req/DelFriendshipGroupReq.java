package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

@Data
public class DelFriendshipGroupReq extends AbstractRequest {
    private String groupName;
    private Long groupId;
    private Long fromId;
}
