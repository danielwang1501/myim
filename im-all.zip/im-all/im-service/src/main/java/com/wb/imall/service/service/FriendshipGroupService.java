package com.wb.imall.service.service;

import com.wb.imall.service.entity.FriendshipGroupEntity;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.model.req.AddFriendshipGroupReq;
import com.wb.imall.service.model.req.DelFriendshipGroupReq;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-20
 */
public interface FriendshipGroupService extends BaseService<FriendshipGroupEntity> {

    void addGroup(AddFriendshipGroupReq req);

    void deleteGroup(DelFriendshipGroupReq req);
}
