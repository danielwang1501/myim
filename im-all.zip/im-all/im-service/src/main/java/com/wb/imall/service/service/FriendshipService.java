package com.wb.imall.service.service;

import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.entity.FriendshipEntity;
import com.wb.imall.service.model.req.AddFriendReq;
import com.wb.imall.service.model.req.AddOrRemoveBlackReq;
import com.wb.imall.service.model.req.CheckBlackReq;
import com.wb.imall.service.model.req.CheckFriendshipReq;
import com.wb.imall.service.model.req.DeleteFriendshipReq;
import com.wb.imall.service.model.req.FriendshipDto;
import com.wb.imall.service.model.req.ImportFriendshipReq;
import com.wb.imall.service.model.req.QueryFriendshipReq;
import com.wb.imall.service.model.req.UpdateFriendReq;
import com.wb.imall.service.model.resp.CheckBlackResp;
import com.wb.imall.service.model.resp.CheckFriendshipResp;
import com.wb.imall.service.model.resp.FriendshipResp;
import com.wb.imall.service.model.resp.ImportFriendshipResp;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-18
 */
public interface FriendshipService extends BaseService<FriendshipEntity> {
    ImportFriendshipResp importFriendship(ImportFriendshipReq req);

    boolean addFriend(AddFriendReq req);

    void doAddFriend(Integer appId, Long fromId, FriendshipDto dto);

    boolean updateFriend(UpdateFriendReq req);

    boolean deleteFriend(DeleteFriendshipReq req);

    boolean deleteAllFriend(DeleteFriendshipReq req);

    FriendshipResp queryOne(QueryFriendshipReq req);

    List<FriendshipResp> queryAll(QueryFriendshipReq req);

    List<CheckFriendshipResp> checkFriendship(CheckFriendshipReq req);


    void addBlack(AddOrRemoveBlackReq req);

    void removeBlack(AddOrRemoveBlackReq req);

    List<CheckBlackResp> checkBlack(CheckBlackReq req);
}
