package com.wb.imall.service.enums;

public enum BlackRelationType {

    NONE(0),
    A2B(1),
    B2A(2),
    ALL(3),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    BlackRelationType(int code) {
        this.code = code;
    }
}
