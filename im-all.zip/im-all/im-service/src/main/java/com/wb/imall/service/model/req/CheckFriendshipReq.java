package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

import java.util.Set;

@Data
public class CheckFriendshipReq extends AbstractRequest {
    private Long fromId;
    private Set<Long> toIds;
    private Integer checkType;
}
