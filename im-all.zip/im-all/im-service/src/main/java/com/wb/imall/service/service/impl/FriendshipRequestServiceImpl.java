package com.wb.imall.service.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.lang.Pair;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.util.BeanUtil;
import com.wb.imall.service.entity.FriendshipRequestEntity;
import com.wb.imall.service.enums.FriendRequestApproveStatus;
import com.wb.imall.service.enums.FriendRequestReadStatus;
import com.wb.imall.service.enums.ImServiceCode;
import com.wb.imall.service.mapper.FriendshipRequestDao;
import com.wb.imall.service.model.req.ApproveFriendRequestReq;
import com.wb.imall.service.model.req.FriendshipDto;
import com.wb.imall.service.model.req.ReadFriendRequestReq;
import com.wb.imall.service.model.resp.FriendshipRequestResp;
import com.wb.imall.service.service.FriendshipRequestService;
import com.wb.imall.service.service.FriendshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-19
 */
@Service
public class FriendshipRequestServiceImpl extends BaseServiceImpl<FriendshipRequestDao, FriendshipRequestEntity> implements FriendshipRequestService {

    @Autowired
    private FriendshipService friendshipService;

    @Override
    public void add(Integer appId, Long fromId, FriendshipDto dto) {
        LambdaQueryWrapper<FriendshipRequestEntity> fromQuery = Wrappers.lambdaQuery(FriendshipRequestEntity.class)
                .eq(FriendshipRequestEntity::getAppId, appId)
                .eq(FriendshipRequestEntity::getFromId, fromId)
                .eq(FriendshipRequestEntity::getToId, dto.getToId());
        Optional<FriendshipRequestEntity> requestOpt = this.unique(fromQuery);
        LocalDateTime now = LocalDateTime.now();
        FriendshipRequestEntity entity = null;
        if (requestOpt.isPresent()) {
            // 修改记录内容和更新时间
            LambdaUpdateWrapper<FriendshipRequestEntity> updateWrapper = Wrappers.lambdaUpdate(FriendshipRequestEntity.class)
                    .set(StringUtils.isNotBlank(dto.getAddSource()), FriendshipRequestEntity::getAddSource, dto.getAddSource())
                    .set(StringUtils.isNotBlank(dto.getAddWording()), FriendshipRequestEntity::getAddWording, dto.getAddWording())
                    .set(StringUtils.isNotBlank(dto.getRemark()), FriendshipRequestEntity::getRemark, dto.getRemark())
                    .eq(FriendshipRequestEntity::getAppId, appId)
                    .eq(FriendshipRequestEntity::getFromId, fromId)
                    .eq(FriendshipRequestEntity::getToId, dto.getToId());
            if (!this.upldate(updateWrapper)) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "添加好友请求失败");
            }
        } else {
            entity = new FriendshipRequestEntity();
            entity.setId(IdWorker.getId());
            entity = requestOpt.get();
            entity.setAddSource(dto.getAddSource());
            entity.setAddWording(dto.getAddWording());
            entity.setRemark(dto.getRemark());
            entity.setFromId(fromId);
            entity.setToId(dto.getToId());
            entity.setApproveStatus(FriendRequestApproveStatus.INITIAL.getCode());
            entity.setReadStatus(FriendRequestReadStatus.UNREAD.getCode());
            entity.setCreationTime(now);
            if (!this.insert(entity)) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "添加好友请求失败");
            }
        }
    }

    @Override
    @Transactional
    public void approve(ApproveFriendRequestReq req) {
        Optional<FriendshipRequestEntity> entityOpt = this.unique(req.getAppId(), req.getId());
        if (!entityOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有申请不存在");
        }
        FriendshipRequestEntity entity = entityOpt.get();
        if (entity.getApproveStatus() != FriendRequestApproveStatus.INITIAL.getCode()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有申请已被审批");
        }
        Long operatorId = req.getOperatorId();
        if (req.getStatus() == FriendRequestApproveStatus.AGREE.getCode()) {
            // 同意
            FriendshipDto friendshipDto = new FriendshipDto();
            friendshipDto.setAddSource(entity.getAddSource());
            friendshipDto.setRemark(entity.getRemark());
            friendshipDto.setAddWording(entity.getAddWording());
            friendshipDto.setToId(entity.getToId());
            // 添加好友
            friendshipService.doAddFriend(req.getAppId(), entity.getFromId(), friendshipDto);
        } else {
            // 拒绝
        }
        // 更新状态
        FriendshipRequestEntity updateEntity = new FriendshipRequestEntity();
        updateEntity.setId(req.getId());
        updateEntity.setApproveStatus(req.getStatus());
        if (!this.upldate(entity)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有申请审批失败");
        }
    }

    @Override
    public void read(ReadFriendRequestReq req) {
        // 更新状态
        LambdaUpdateWrapper<FriendshipRequestEntity> updateWrapper = Wrappers.lambdaUpdate(FriendshipRequestEntity.class)
                .set(FriendshipRequestEntity::getReadStatus, FriendRequestReadStatus.READ.getCode())
                .eq(FriendshipRequestEntity::getAppId, req.getAppId())
                .eq(FriendshipRequestEntity::getFromId, req.getFromId());
        boolean res = this.update(updateWrapper);
        if (!res) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "已读失败");
        }
    }

    @Override
    public Pair<List<FriendshipRequestResp>, Long> list(ReadFriendRequestReq req) {
        List<FriendshipRequestResp> resp = new ArrayList<>(0);
        Long total = -1L;
        LambdaQueryWrapper<FriendshipRequestEntity> queryWrapper = Wrappers.lambdaQuery(FriendshipRequestEntity.class)
                .eq(FriendshipRequestEntity::getAppId, req.getAppId())
                .eq(FriendshipRequestEntity::getFromId, req.getFromId());
        if (req.getPage() == -1L) {
            // 不分页，返回全部
            List<FriendshipRequestEntity> entityList = this.list(queryWrapper);
            resp = BeanUtil.sourceToTarget(entityList, FriendshipRequestResp.class);
            total = Long.valueOf(resp.size());
        } else {
            // 分页
            Page<FriendshipRequestEntity> pageObj = new Page<>(req.getPage(), req.getLimit());
            Page<FriendshipRequestEntity> pageResp = this.page(pageObj, queryWrapper);
            List<FriendshipRequestEntity> records = pageResp.getRecords();
            if (CollectionUtil.isNotEmpty(records)) {
                resp = BeanUtil.sourceToTarget(records, FriendshipRequestResp.class);
                total = pageResp.getTotal();
            }
        }
        return Pair.of(resp, total);
    }
    // TODO 获取好友申请列表、已读好友申请
}
