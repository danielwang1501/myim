package com.wb.imall.service.model.req;

import com.wb.imall.common.model.RequestBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class UserDto extends RequestBase {
    private String userId;

    /**
     * 昵称
     */
    private String nickName;

    private String password;

    private String photo;

    private Integer userSex;

    /**
     * 生日
     */
    private String birthDay;

    /**
     * 地址
     */
    private String location;

    /**
     * 个性签名
     */
    private String selfSignature;

    /**
     * 加好友验证类型（Friend_AllowType） 1无需验证 2需要验证
     */
    private Integer friendAllowType;

    /**
     * 禁用标识 1禁用
     */
    private Integer forbiddenFlag;

    /**
     * 管理员禁止用户添加加好友：0 未禁用 1 已禁用
     */
    private Integer disableAddFriend;

    /**
     * 禁言标识 1禁言
     */
    private Integer silentFlag;

    /**
     * 用户类型 1普通用户 2客服 3机器人
     */
    private Integer userType;

    private String extra;
}
