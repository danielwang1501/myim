package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import com.wb.imall.service.enums.FriendshipStatusEnum;
import lombok.Data;

import java.util.List;

@Data
public class ImportFriendshipReq extends AbstractRequest {
    private Long fromId;
    private List<ImportFriendDto> friendItem;

    @Data
    public static class ImportFriendDto {
        private Long toId;
        private String remark;
        private String addSource;
        private Integer status = FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode();
        private Integer black = FriendshipStatusEnum.BLACK_STATUS_NO_BLACK.getCode();
    }
}
