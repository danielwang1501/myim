package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

@Data
public class GetGroupMemberReq extends AbstractRequest {
    private Long groupId;
    private Long memberId;
}
