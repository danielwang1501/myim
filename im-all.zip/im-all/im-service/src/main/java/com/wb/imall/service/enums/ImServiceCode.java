package com.wb.imall.service.enums;

import com.wb.imall.common.exception.ApplicationExceptionEnum;

public enum ImServiceCode implements ApplicationExceptionEnum {
    USER_NOT_FOUND(21001),
    ADD_FRIENDSHIP_FAIL(21002),
    ADD_FRIENDSHIP_EXIST(21003),
    UPDATE_FRIENDSHIP_FAIL(21004),
    DELETE_FRIENDSHIP_FAIL(21005),
    FRIENDSHIP_NOT_EXIST(21006),
    BUSINESS_LOGIC(21998),
    OTHERS(21999),

    ;

    private final int code;

    ImServiceCode(int code) {
        this.code = code;
    }

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getError() {
        return null;
    }
}
