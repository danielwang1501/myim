package com.wb.imall.service.controller;


import com.wb.imall.common.R;
import com.wb.imall.service.entity.UserDataEntity;
import com.wb.imall.service.model.req.ImportUserReq;
import com.wb.imall.service.model.req.QueryUserReq;
import com.wb.imall.service.model.req.UserDto;
import com.wb.imall.service.model.resp.ImportUserResp;
import com.wb.imall.service.service.UserDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-05
 */
@RestController
@RequestMapping("/user")
public class UserDataController {
    @Autowired
    private UserDataService userDataService;

    @GetMapping("insert")
    public R<String> insert(Integer n) {
        UserDataEntity e = new UserDataEntity();
        e.setAppId(n);
        e.setBirthDay("2020");
        e.setDisableAddFriend(0);
        e.setNickName("haha");
        e.setId(Long.valueOf(n));
        e.setUserId(n.toString());
        e.setCreationTime(LocalDateTime.now());
        e.setUpdateTime(LocalDateTime.now());
        userDataService.insert(e);
        return R.ok(e);
    }

    @PostMapping("/import")
    public R<ImportUserResp> importData(@RequestBody ImportUserReq req, Integer appId) {
        return userDataService.importUser(req, appId);
    }

    @GetMapping("/delete")
    public R delete(@RequestParam List<Long> ids) {
        if (userDataService.removeByIds(ids)) {
            return R.ok();
        }
        return R.error();
    }

    @PostMapping("/update")
    public R update(@RequestBody UserDto userDto) {
        if (userDataService.update(userDto)) {
            return R.ok();
        }
        return R.error();
    }

    @GetMapping("/query")
    public R<UserDto> query(@RequestParam QueryUserReq req) {
//        return userDataService.u(req);
        return null;
    }

    @GetMapping("/list")
    public R<List<UserDto>> queryList(@RequestParam Set<Long> ids) {
        List<UserDto> userDtos = userDataService.queryList(ids);
        return R.ok(userDtos);
    }
}
