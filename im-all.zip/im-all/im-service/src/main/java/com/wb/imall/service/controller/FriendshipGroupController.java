package com.wb.imall.service.controller;


import com.wb.imall.common.R;
import com.wb.imall.service.model.req.AddFriendshipGroupReq;
import com.wb.imall.service.model.req.DelFriendshipGroupReq;
import com.wb.imall.service.service.FriendshipGroupMemberService;
import com.wb.imall.service.service.FriendshipGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-20
 */
@RestController
@RequestMapping("/friendshipGroup")
public class FriendshipGroupController {
    @Autowired
    private FriendshipGroupService friendshipGroupService;
    @Autowired
    private FriendshipGroupMemberService friendshipGroupMemberService;

    @PostMapping("/addGroup")
    public R addGroup(@RequestBody AddFriendshipGroupReq req) {
        friendshipGroupService.addGroup(req);
        return R.ok();
    }

    @PostMapping("/delete")
    public R deleteGroup(@RequestBody DelFriendshipGroupReq req) {
        friendshipGroupService.deleteGroup(req);
        return R.ok();
    }

}
