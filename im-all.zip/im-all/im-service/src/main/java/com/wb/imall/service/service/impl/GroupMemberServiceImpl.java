package com.wb.imall.service.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.lang.Pair;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.util.BeanUtil;
import com.wb.imall.common.util.WrapperUtil;
import com.wb.imall.service.entity.GroupEntity;
import com.wb.imall.service.entity.GroupMemberEntity;
import com.wb.imall.service.enums.GroupMemberRole;
import com.wb.imall.service.enums.ImServiceCode;
import com.wb.imall.service.mapper.GroupMemberDao;
import com.wb.imall.service.model.req.GetGroupMemberReq;
import com.wb.imall.service.model.req.GetJoinedGroupReq;
import com.wb.imall.service.model.req.GroupMemberDto;
import com.wb.imall.service.model.req.ImportGroupMemberReq;
import com.wb.imall.service.model.req.QueryGroupMemberReq;
import com.wb.imall.service.model.req.UpdateGroupMemberRoleReq;
import com.wb.imall.service.model.resp.AddMemberResp;
import com.wb.imall.service.model.resp.GetRoleInGroupResp;
import com.wb.imall.service.model.resp.GroupMemberResp;
import com.wb.imall.service.model.resp.GroupResp;
import com.wb.imall.service.service.GroupMemberService;
import com.wb.imall.service.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@Service
public class GroupMemberServiceImpl extends BaseServiceImpl<GroupMemberDao, GroupMemberEntity> implements GroupMemberService {

    @Autowired
    private GroupService groupService;

    @Transactional
    @Override
    public List<AddMemberResp> importGroupMember(ImportGroupMemberReq req) {
        Optional<GroupEntity> groupOpt = groupService.unique(req.getAppId(), req.getGroupId());
        if (!groupOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群组不存在");
        }
        List<AddMemberResp> respList = new ArrayList<>();
        List<GroupMemberDto> groupMemberList = req.getGroupMemberList();
        for (GroupMemberDto dto : groupMemberList) {
            AddMemberResp resp = new AddMemberResp();
            resp.setMemberId(dto.getMemberId());
            try {
                this.addGroupMember(req.getAppId(), req.getGroupId(), dto);
                resp.setResult(0);
                resp.setMessage("SUCCESS");
            } catch (ApplicationException ex) {
                resp.setResult(1);
                resp.setMessage(ex.getErrMsg());
            }
        }
        return respList;
    }

    @Transactional
    @Override
    public void addGroupMember(Integer appId, Long groupId, GroupMemberDto dto) {
        if (dto.getRole() == GroupMemberRole.OWNER.getCode()) {
            // if it's role is owner, check if it already is owner.
            LambdaQueryWrapper<GroupMemberEntity> lqw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, appId)
                    .eq(GroupMemberEntity::getGroupId, groupId)
//                .eq(GroupMemberEntity::getMemberId, dto.getMemberId())
                    .eq(GroupMemberEntity::getRole, GroupMemberRole.OWNER.getCode());
            long count = this.count(lqw);
            if (count > 0) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "此群已经有群主了");
            }
        }
        // check if member has already in group, then insert, otherwise update
        LambdaQueryWrapper<GroupMemberEntity> uniqueCheckQw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, appId)
                .eq(GroupMemberEntity::getGroupId, groupId)
                .eq(GroupMemberEntity::getMemberId, dto.getMemberId());
        Optional<GroupMemberEntity> gmOpt = this.unique(uniqueCheckQw);
        GroupMemberEntity entity = BeanUtil.sourceToTarget(dto, GroupMemberEntity.class);
        if (!gmOpt.isPresent()) {
            entity.setGroupId(groupId);
            boolean ret = this.insert(entity);
            if (!ret) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "添加群成员失败");
            }
        } else {
            GroupMemberEntity groupMemberEntity = gmOpt.get();
            if (groupMemberEntity.getRole() == GroupMemberRole.LEAVE.getCode()) {
                // 更新其信息
                entity.setId(groupMemberEntity.getId());
                entity.setJoinTime(System.currentTimeMillis());
                boolean ret = this.upldate(entity);
                if (!ret) {
                    throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群成员已离开，更新信息失败");
                }
            }
        }
    }

    @Override
    public GetRoleInGroupResp getRoleInGroup(Integer appId, Long groupId, Long memberId) {
        LambdaQueryWrapper<GroupMemberEntity> lqw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, appId)
                .eq(GroupMemberEntity::getGroupId, groupId)
                .eq(GroupMemberEntity::getMemberId, memberId)
                .ne(GroupMemberEntity::getRole, GroupMemberRole.LEAVE.getCode());
        Optional<GroupMemberEntity> gmOpt = this.unique(lqw);
        if (!gmOpt.isPresent()) {
            return null;
        }
        GetRoleInGroupResp resp = BeanUtil.sourceToTarget(gmOpt.get(), GetRoleInGroupResp.class);
        return resp;
    }

    @Override
    public Pair<List<GroupMemberResp>, Long> queryGroupMember(QueryGroupMemberReq req) {
        LambdaQueryWrapper<GroupMemberEntity> lqw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, req.getAppId())
                .eq(GroupMemberEntity::getGroupId, req.getGroupId());
        Long total = -1L;
        List<GroupMemberEntity> entities = null;
        if (req.getLimit() == -1) {
            // 不分页
            entities = this.list(lqw);
        } else {
            Page<GroupMemberEntity> page = this.page(new Page<>(req.getPage(), req.getLimit()), lqw);
            entities = page.getRecords();
            total = page.getTotal();
        }
        if (CollectionUtil.isEmpty(entities)) {
            return Pair.of(new ArrayList<>(), total);
        }
        List<GroupMemberResp> r = BeanUtil.sourceToTarget(entities, GroupMemberResp.class);
        return Pair.of(r, total);
    }

    @Override
    public List<GroupResp> getJoinedGroup(GetJoinedGroupReq req) {
        // 获取用户加入的群ID
        LambdaQueryWrapper<GroupMemberEntity> lqw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, req.getAppId())
                .select(GroupMemberEntity::getGroupId)
                .eq(GroupMemberEntity::getMemberId, req.getMemberId())
                .ne(GroupMemberEntity::getRole, GroupMemberRole.LEAVE.getCode());
        List<GroupMemberEntity> groupMemberList = this.list(lqw);
        if (CollectionUtil.isEmpty(groupMemberList)) {
            return null;
        }
        Set<Long> groupIds = groupMemberList.stream().map(GroupMemberEntity::getId).collect(Collectors.toSet());
        // 根据群ID和群类型获取群组信息
        LambdaQueryWrapper<GroupEntity> gLqw = WrapperUtil.queryWithAppId(GroupEntity.class, req.getAppId())
                .in(GroupEntity::getId, groupIds)
                .in(CollectionUtil.isNotEmpty(req.getGroupTypes()), GroupEntity::getGroupType, req.getGroupTypes());
        List<GroupEntity> groupList = groupService.list(gLqw);
        if (CollectionUtil.isEmpty(groupList)) {
            return null;
        }
        List<GroupResp> res = BeanUtil.sourceToTarget(groupList, GroupResp.class);
        return res;
    }

    @Override
    public GroupMemberDto getGroupMemberInfo(GetGroupMemberReq req) {
        LambdaQueryWrapper<GroupMemberEntity> lqw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, req.getAppId())
                .eq(GroupMemberEntity::getGroupId, req.getGroupId())
                .eq(GroupMemberEntity::getMemberId, req.getMemberId());
        Optional<GroupMemberEntity> entityOpt = this.unique(lqw);
        if (!entityOpt.isPresent()) {
            return null;
        }
        return BeanUtil.sourceToTarget(entityOpt.get(), GroupMemberDto.class);
    }

    @Override
    public void updateGroupMemberRole(UpdateGroupMemberRoleReq req) {
        LambdaQueryWrapper<GroupMemberEntity> lqw = WrapperUtil.queryWithAppId(GroupMemberEntity.class, req.getAppId())
                .eq(GroupMemberEntity::getGroupId, req.getGroupId())
                .eq(GroupMemberEntity::getMemberId, req.getMemberId());
        GroupMemberEntity entity = new GroupMemberEntity();
        entity.setRole(req.getRole());
        boolean ret = this.update(entity, lqw);
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "更新群成员角色失败");
        }
    }
}
