package com.wb.imall.service.enums;

public enum FriendshipCheckType {

    SINGLE_SIDE(1),
    DOUBLE_SIDE(2),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    FriendshipCheckType(int code) {
        this.code = code;
    }
}
