package com.wb.imall.service.service;

import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.entity.FriendshipGroupMemberEntity;
import com.wb.imall.service.model.req.AddAndDeleteFriendshipGroupMemberReq;

import java.util.Set;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-20
 */
public interface FriendshipGroupMemberService extends BaseService<FriendshipGroupMemberEntity> {
    void add(AddAndDeleteFriendshipGroupMemberReq req);

    Set<Long> doAddGroupMember(Long groupId, Long toId);

    void deleteGroupMember(Integer appId, Long groupId);
    // TODO 添加群成员、删除群成员接口

    void addGroupManager(AddAndDeleteFriendshipGroupMemberReq req);

    void deleteGroupManager(AddAndDeleteFriendshipGroupMemberReq req);
}
