package com.wb.imall.service.exception;

import cn.hutool.core.collection.CollectionUtil;
import com.wb.imall.common.R;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.exception.ApplicationExceptionEnum;
import com.wb.imall.common.exception.BasisCode;
import com.wb.imall.service.config.Ii8nMessageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Rest接口异常处理器
 */
@RequiredArgsConstructor
@RestControllerAdvice(annotations = {RestController.class})
@Slf4j
public class AppExceptionHandler {
    private final Ii8nMessageService messageService;

    /**
     * 处理业务异常
     */
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ApplicationException.class)
    public R handleApplicationException(ApplicationException e) {
        ApplicationExceptionEnum errorCode = e.getErrorInfo();
        return R.error(errorCode);
    }


    //    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = SQLException.class)
    public R sqlException(SQLException exception) {
        log.error("sql has exception", exception);
        return R.error(BasisCode.DB_ERROR);
    }

    //    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public R handleException(Exception e) {
        log.error(e.getMessage(), e);
        return R.error(BasisCode.SERVER_ERROR);
    }


    //    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = BindException.class)
    public R bindException(BindException e) {
        log.error("参数绑定失败错误!", e);
        return validatorException(e.getBindingResult());
    }

    /**
     * 处理请求参数格式错误 @RequestParam上validate失败后抛出的异常是javax.validation.ConstraintViolationException
     *
     * @param e 请求参数格式错误
     * @return 响应信息
     */
    @ExceptionHandler(ConstraintViolationException.class)
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public R exception(ConstraintViolationException e) {
        String message = e.getConstraintViolations().stream().map(ConstraintViolation::getMessage).collect(Collectors.joining());
        return R.error(BasisCode.PARAM_VALID).msg(message);
    }

    //    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public R exception(MethodArgumentNotValidException e) {
        log.error("参数校验错误!", e);
        return validatorException(e.getBindingResult());
    }

    /**
     * 忽略参数异常处理器
     *
     * @param e 忽略参数异常
     * @return ResponseResult
     */
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public R exception(MissingServletRequestParameterException e) {
        log.error("", e);
        return R.error(BasisCode.PARAM_VALID).msg("请求参数 " + e.getParameterName() + " 不能为空");
    }


    /**
     * 缺少请求体异常处理器
     *
     * @param e 异常
     * @return 响应信息
     */
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    public R exception(HttpMessageNotReadableException e) {
        log.error("参数校验错误!", e);
        return R.error(BasisCode.PARAM_VALID);
    }

    private R validatorException(BindingResult bindingResult) {
        final List<ObjectError> errorList = bindingResult.getAllErrors();
        final String message = "参数错误!";
        if (errorList != null) {
            Map<String, Object> errMap = new HashMap<>();
            bindingResult.getFieldErrors().forEach(item -> {
                errMap.put(item.getField(), item.getDefaultMessage());
            });

            if (CollectionUtil.isNotEmpty(errorList)) {
                log.error("错误参数详情如下:{}", errorList);
                return R.error(BasisCode.PARAM_VALID).msg(errorList.toString());
            }
        }
        return R.error(BasisCode.PARAM_VALID);
    }
}
