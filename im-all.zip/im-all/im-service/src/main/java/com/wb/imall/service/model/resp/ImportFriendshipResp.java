package com.wb.imall.service.model.resp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@ToString
public class ImportFriendshipResp {
    private List<Long> successIds = new ArrayList<>();
    private List<Long> errorIds = new ArrayList<>();
}
