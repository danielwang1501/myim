package com.wb.imall.service.controller;


import com.wb.imall.common.R;
import com.wb.imall.service.model.req.GetJoinedGroupReq;
import com.wb.imall.service.model.resp.GroupResp;
import com.wb.imall.service.service.GroupMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 前端控制器
 * todo: 获取加入的所有群信息、解散群、转让群、拉人入群、移出群聊、退出群聊
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@RestController
@RequestMapping("/grpmem")
public class GroupMemberController {

    @Autowired
    private GroupMemberService groupMemberService;

    @PostMapping("/getJoinedGroup")
    public R<List<GroupResp>> getJoinedGroup(GetJoinedGroupReq req) {
        List<GroupResp> joinedGroup = groupMemberService.getJoinedGroup(req);
        return R.ok(joinedGroup);
    }
}
