package com.wb.imall.service.model.resp;

import lombok.Data;

@Data
public class CheckFriendshipResp {
    private Long toId;
    private Integer friendshipRelationType;
}
