package com.wb.imall.service.service;

import cn.hutool.core.lang.Pair;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.entity.FriendshipRequestEntity;
import com.wb.imall.service.model.req.ApproveFriendRequestReq;
import com.wb.imall.service.model.req.FriendshipDto;
import com.wb.imall.service.model.req.ReadFriendRequestReq;
import com.wb.imall.service.model.resp.FriendshipRequestResp;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-19
 */
public interface FriendshipRequestService extends BaseService<FriendshipRequestEntity> {
    void add(Integer appId, Long fromId, FriendshipDto dto);

    // TODO 获取好友申请列表、申请好友申请、已读好友申请
    void approve(ApproveFriendRequestReq req);

    void read(ReadFriendRequestReq req);

    Pair<List<FriendshipRequestResp>, Long> list(ReadFriendRequestReq req);

}
