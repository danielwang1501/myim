package com.wb.imall.service.service.impl;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.wb.imall.common.R;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.util.BeanUtil;
import com.wb.imall.service.entity.UserDataEntity;
import com.wb.imall.service.mapper.UserDataDao;
import com.wb.imall.service.model.req.ImportUserReq;
import com.wb.imall.service.model.req.UserDto;
import com.wb.imall.service.model.resp.ImportUserResp;
import com.wb.imall.service.service.UserDataService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-05
 */
@Service
public class UserDataServiceImpl extends BaseServiceImpl<UserDataDao, UserDataEntity> implements UserDataService {

    @Override
    public R<ImportUserResp> importUser(ImportUserReq req, Integer appId) {
        if (req.getUserList().size() > 100) {
            // TODO 返回数量过多
        }
        List<UserDataEntity> entities = BeanUtil.sourceToTarget(req.getUserList(), UserDataEntity.class);
        ImportUserResp resp = new ImportUserResp();
        entities.stream().forEach(obj -> {
            obj.setAppId(appId);
            obj.setId(IdWorker.getId());
            obj.setUserId(obj.getId().toString());
//            if (appId == 1) {
//                throw new RuntimeException();
//            }
            try {
                if (this.insert(obj)) {
                    resp.getSuccessIds().add(obj.getUserId());
                } else {
                    resp.getErrorIds().add(obj.getUserId());
                }
            } catch (Exception e) {
                e.printStackTrace();
                resp.getErrorIds().add(obj.getUserId());
            }
        });
        if (resp.getErrorIds().size() > 0) {
            return R.error(resp);
        }
        return R.ok(resp);
    }

    @Override
    public boolean update(UserDto userDto) {
        UserDataEntity u = BeanUtil.sourceToTarget(userDto, UserDataEntity.class);
        return this.upldate(u);

    }

    @Override
    public List<UserDto> queryList(Set<Long> ids) {
        List<UserDataEntity> entities = this.listByIds(ids);
        List<UserDto> userDtos = BeanUtil.sourceToTarget(entities, UserDto.class);
        return userDtos;
    }
}
