package com.wb.imall.service.model.req;

import com.wb.imall.common.model.PagedRequest;
import lombok.Data;

@Data
public class QueryGroupMemberReq extends PagedRequest {
    private Long groupId;
}
