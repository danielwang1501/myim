package com.wb.imall.service.service;

import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.entity.GroupEntity;
import com.wb.imall.service.model.req.CreateGroupReq;
import com.wb.imall.service.model.req.DestroyGroupReq;
import com.wb.imall.service.model.req.GetGroupInfoReq;
import com.wb.imall.service.model.req.ImportGroupReq;
import com.wb.imall.service.model.req.TransferGroupReq;
import com.wb.imall.service.model.req.UpdateGroupReq;
import com.wb.imall.service.model.resp.GroupResp;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
public interface GroupService extends BaseService<GroupEntity> {
    void importGroup(ImportGroupReq req);

    void updateGroup(UpdateGroupReq req);

    void createGroup(CreateGroupReq req);

    GroupResp getGroup(GetGroupInfoReq grpId);

    void destroy(DestroyGroupReq req);

    void transfer(TransferGroupReq req);
}
