package com.wb.imall.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.util.BeanUtil;
import com.wb.imall.service.entity.FriendshipEntity;
import com.wb.imall.service.entity.UserDataEntity;
import com.wb.imall.service.enums.AllowFriendType;
import com.wb.imall.service.enums.BlackRelationType;
import com.wb.imall.service.enums.FriendshipCheckType;
import com.wb.imall.service.enums.FriendshipRelationType;
import com.wb.imall.service.enums.FriendshipStatusEnum;
import com.wb.imall.service.enums.ImServiceCode;
import com.wb.imall.service.mapper.FriendshipDao;
import com.wb.imall.service.model.req.AddFriendReq;
import com.wb.imall.service.model.req.AddOrRemoveBlackReq;
import com.wb.imall.service.model.req.CheckBlackReq;
import com.wb.imall.service.model.req.CheckFriendshipReq;
import com.wb.imall.service.model.req.DeleteFriendshipReq;
import com.wb.imall.service.model.req.FriendshipDto;
import com.wb.imall.service.model.req.ImportFriendshipReq;
import com.wb.imall.service.model.req.QueryFriendshipReq;
import com.wb.imall.service.model.req.UpdateFriendReq;
import com.wb.imall.service.model.resp.CheckBlackResp;
import com.wb.imall.service.model.resp.CheckFriendshipResp;
import com.wb.imall.service.model.resp.FriendshipResp;
import com.wb.imall.service.model.resp.ImportFriendshipResp;
import com.wb.imall.service.service.FriendshipRequestService;
import com.wb.imall.service.service.FriendshipService;
import com.wb.imall.service.service.UserDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-18
 */
@Service
public class FriendshipServiceImpl extends BaseServiceImpl<FriendshipDao, FriendshipEntity> implements FriendshipService {

    @Autowired
    private UserDataService userDataService;

    @Autowired
    private FriendshipRequestService friendshipRequestService;

    @Override
    public ImportFriendshipResp importFriendship(ImportFriendshipReq req) {
        if (req.getFriendItem().size() > 100) {
            // TODO  数据量太大
        }
        ImportFriendshipResp resp = new ImportFriendshipResp();
        for (ImportFriendshipReq.ImportFriendDto dto : req.getFriendItem()) {
            Long id = IdWorker.getId();
            FriendshipEntity entity = BeanUtil.sourceToTarget(dto, FriendshipEntity.class);
            entity.setId(id);
            entity.setFromId(req.getFromId());
            try {
                entity.setAppId(req.getAppId());
                if (this.insert(entity)) {
                    resp.getSuccessIds().add(entity.getToId());
                } else {
                    resp.getErrorIds().add(entity.getToId());
                }
            } catch (Exception e) {
                resp.getErrorIds().add(entity.getToId());
            }
        }
        return resp;
    }

    @Override
    public boolean addFriend(AddFriendReq req) {
        Optional<UserDataEntity> fromOpt = userDataService.unique(req.getAppId(), req.getFromId());
        if (!fromOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.USER_NOT_FOUND, "用户" + req.getFromId() + "不存在");
        }
        Optional<UserDataEntity> toOpt = userDataService.unique(req.getAppId(), req.getToItem().getToId());
        if (!toOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.USER_NOT_FOUND, "用户" + req.getToItem().getToId() + "不存在");
        }
        UserDataEntity toUser = toOpt.get();
        // 查看对方的好友添加方式
        if (toUser.getDisableAddFriend() == 1) {
            throw new ApplicationException(ImServiceCode.ADD_FRIENDSHIP_FAIL, "用户" + req.getToItem().getToId() + "不允许添加好友");
        }
        if (toUser.getFriendAllowType() != null && toUser.getFriendAllowType() == AllowFriendType.NEED.getCode()) {
            // 需要申请，就插入一条好友申请逻辑
            friendshipRequestService.add(req.getAppId(), req.getFromId(), req.getToItem());
        } else {
            doAddFriend(req.getAppId(), req.getFromId(), req.getToItem());
        }
        return true;
    }

    @Override
    public boolean updateFriend(UpdateFriendReq req) {
        Optional<UserDataEntity> fromOpt = userDataService.unique(req.getAppId(), req.getFromId());
        if (!fromOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.USER_NOT_FOUND, "用户" + req.getFromId() + "不存在");
        }
        Optional<UserDataEntity> toOpt = userDataService.unique(req.getAppId(), req.getToItem().getToId());
        if (!toOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.USER_NOT_FOUND, "用户" + req.getToItem().getToId() + "不存在");
        }
        this.doUpdateFriend(req.getAppId(), req.getFromId(), req.getToItem());
        return true;
    }

    @Override
    public boolean deleteFriend(DeleteFriendshipReq req) {
        LambdaQueryWrapper<FriendshipEntity> fromQuery = Wrappers.lambdaQuery(FriendshipEntity.class)
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getToId, req.getToId());
        Optional<FriendshipEntity> fromOpt = this.unique(fromQuery);
        if (fromOpt.isPresent()) {
            FriendshipEntity entity = fromOpt.get();
            if (entity.getStatus() != FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                // 执行删除操作
                LambdaUpdateWrapper<FriendshipEntity> updateWrapper = Wrappers.lambdaUpdate(FriendshipEntity.class)
                        .set(FriendshipEntity::getStatus, FriendshipStatusEnum.FRIEND_STATUS_DELETE.getCode())
                        .eq(FriendshipEntity::getAppId, req.getAppId())
                        .eq(FriendshipEntity::getFromId, req.getFromId())
                        .eq(FriendshipEntity::getToId, req.getToId());
                if (!this.update(updateWrapper)) {
                    throw new ApplicationException(ImServiceCode.DELETE_FRIENDSHIP_FAIL, "删除好友失败");
                }
            }
        } else {
            // 没有好友关系
            throw new ApplicationException(ImServiceCode.FRIENDSHIP_NOT_EXIST, "不存在此好友关系");
        }
        return true;
    }

    @Override
    public boolean deleteAllFriend(DeleteFriendshipReq req) {
        LambdaQueryWrapper<FriendshipEntity> fromQuery = Wrappers.lambdaQuery(FriendshipEntity.class)
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getStatus, FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode());
        FriendshipEntity entity = new FriendshipEntity();
        entity.setStatus(FriendshipStatusEnum.FRIEND_STATUS_DELETE.getCode());
        boolean res = this.update(entity, fromQuery);
        if (!res) {
            throw new ApplicationException(ImServiceCode.DELETE_FRIENDSHIP_FAIL, "删除好友失败");
        }
        return res;
    }

    @Override
    public FriendshipResp queryOne(QueryFriendshipReq req) {
        LambdaQueryWrapper<FriendshipEntity> fromQuery = Wrappers.lambdaQuery(FriendshipEntity.class)
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getToId, req.getToId());
        Optional<FriendshipEntity> friendshipOpt = this.unique(fromQuery);
        if (!friendshipOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.FRIENDSHIP_NOT_EXIST, "好有关系不存在");
        }
        FriendshipResp resp = BeanUtil.sourceToTarget(friendshipOpt.get(), FriendshipResp.class);
        return resp;
    }

    @Override
    public List<FriendshipResp> queryAll(QueryFriendshipReq req) {
        LambdaQueryWrapper<FriendshipEntity> fromQuery = Wrappers.lambdaQuery(FriendshipEntity.class)
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId());
        List<FriendshipEntity> fsList = this.list(fromQuery);
        List<FriendshipResp> resp = BeanUtil.sourceToTarget(fsList, FriendshipResp.class);
        return resp;
    }

    @Override
    public List<CheckFriendshipResp> checkFriendship(CheckFriendshipReq req) {
        List<CheckFriendshipResp> respList = new ArrayList<>();
        Integer checkType = req.getCheckType();
        if (checkType == FriendshipCheckType.SINGLE_SIDE.getCode()) {
            // 只需要校验对方是否在通讯录列表
            LambdaQueryWrapper<FriendshipEntity> wrapperForSingleSide = Wrappers.lambdaQuery(FriendshipEntity.class)
                    .eq(FriendshipEntity::getAppId, req.getAppId())
                    .eq(FriendshipEntity::getFromId, req.getFromId())
                    .in(FriendshipEntity::getToId, req.getToIds());
            List<FriendshipEntity> singleSideList = this.list(wrapperForSingleSide);
            for (FriendshipEntity entity : singleSideList) {
                CheckFriendshipResp resp = new CheckFriendshipResp();
                resp.setToId(entity.getToId());
                resp.setFriendshipRelationType(
                        entity.getStatus() == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode() ?
                                FriendshipRelationType.A2B.getCode() : FriendshipRelationType.NONE.getCode());
                respList.add(resp);
            }
        } else {
            // 双向校验比较复杂
            LambdaQueryWrapper<FriendshipEntity> wrapperForward = Wrappers.lambdaQuery(FriendshipEntity.class)
                    .eq(FriendshipEntity::getAppId, req.getAppId())
                    .eq(FriendshipEntity::getFromId, req.getFromId())
                    .in(FriendshipEntity::getToId, req.getToIds());
            List<FriendshipEntity> forwardList = this.list(wrapperForward);

            LambdaQueryWrapper<FriendshipEntity> wrapperBackward = Wrappers.lambdaQuery(FriendshipEntity.class)
                    .eq(FriendshipEntity::getAppId, req.getAppId())
                    .in(FriendshipEntity::getFromId, req.getToIds())
                    .eq(FriendshipEntity::getToId, req.getFromId());
            List<FriendshipEntity> backwardList = this.list(wrapperBackward);

            // 将backwardList转换成map方便校验
            Map<Long, FriendshipEntity> backwardMap = backwardList.stream().collect(Collectors.toMap(FriendshipEntity::getFromId, a -> a));
            // 以from方向校验
            for (FriendshipEntity entity : forwardList) {
                CheckFriendshipResp resp = new CheckFriendshipResp();
                resp.setToId(entity.getToId());
                Integer forwardType = entity.getStatus();
                // 反向查看
                Integer backwardType = FriendshipStatusEnum.FRIEND_STATUS_NO_FRIEND.getCode();
                FriendshipEntity friendEntity = backwardMap.get(entity.getToId());
                if (friendEntity != null) {
                    backwardType = friendEntity.getStatus();
                }
                if (forwardType == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode() && backwardType == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                    resp.setFriendshipRelationType(FriendshipRelationType.ALL.getCode());
                } else if (forwardType == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                    resp.setFriendshipRelationType(FriendshipRelationType.A2B.getCode());
                } else if (backwardType == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                    resp.setFriendshipRelationType(FriendshipRelationType.B2A.getCode());
                }
                if (forwardType == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode() || backwardType == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                    respList.add(resp);
                }
            }
            // 以to方向校验
            Set<Long> toSetByFrom = forwardList.stream().map(FriendshipEntity::getToId).collect(Collectors.toSet());
            Set<Long> fromSetByTo = backwardMap.keySet();
            Set<Long> diffSet = new HashSet<>(fromSetByTo);
            diffSet.removeAll(toSetByFrom);
            for (Long toId : diffSet) {
                FriendshipEntity toEntity = backwardMap.get(toId);
                if (toEntity.getStatus() == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                    CheckFriendshipResp resp = new CheckFriendshipResp();
                    resp.setToId(toId);
                    resp.setFriendshipRelationType(FriendshipRelationType.B2A.getCode());
                    respList.add(resp);
                }
            }

        }
        return respList;
    }

    @Override
    public void addBlack(AddOrRemoveBlackReq req) {
        // 是否已经在黑名单
        LambdaQueryWrapper<FriendshipEntity> queryWrapper = Wrappers.lambdaQuery(FriendshipEntity.class)
                .select(FriendshipEntity::getId, FriendshipEntity::getAppId, FriendshipEntity::getFromId,
                        FriendshipEntity::getToId, FriendshipEntity::getBlack, FriendshipEntity::getStatus)
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getToId, req.getToId());
        FriendshipEntity one = this.getOne(queryWrapper);
        if (Objects.isNull(one)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有关系不存在");
        }
        if (one.getBlack() == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "对方已经在黑名单里了");
        }
        // 修改状态
        LambdaUpdateWrapper<FriendshipEntity> updateWrapper = Wrappers.lambdaUpdate(FriendshipEntity.class)
                .set(FriendshipEntity::getBlack, FriendshipStatusEnum.BLACK_STATUS_NO_BLACK.getCode())
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getToId, req.getToId());
        if (!this.update(updateWrapper)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "添加黑名单失败");
        }
    }

    @Override
    public void removeBlack(AddOrRemoveBlackReq req) {
        // 是否本来就不在黑名单
        LambdaQueryWrapper<FriendshipEntity> queryWrapper = Wrappers.lambdaQuery(FriendshipEntity.class)
                .select(FriendshipEntity::getId, FriendshipEntity::getAppId, FriendshipEntity::getFromId,
                        FriendshipEntity::getToId, FriendshipEntity::getBlack, FriendshipEntity::getStatus)
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getToId, req.getToId());
        FriendshipEntity one = this.getOne(queryWrapper);
        if (Objects.isNull(one)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有关系不存在");
        }
        if (one.getBlack() == FriendshipStatusEnum.BLACK_STATUS_NO_BLACK.getCode()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "对方不在黑名单里");
        }
        // 修改状态
        LambdaUpdateWrapper<FriendshipEntity> updateWrapper = Wrappers.lambdaUpdate(FriendshipEntity.class)
                .set(FriendshipEntity::getBlack, FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode())
                .eq(FriendshipEntity::getAppId, req.getAppId())
                .eq(FriendshipEntity::getFromId, req.getFromId())
                .eq(FriendshipEntity::getToId, req.getToId());
        if (!this.update(updateWrapper)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "接触黑名单失败");
        }
    }

    @Override
    public List<CheckBlackResp> checkBlack(CheckBlackReq req) {
        List<CheckBlackResp> respList = new ArrayList<>();
        Integer checkType = req.getCheckType();
        if (checkType == FriendshipCheckType.SINGLE_SIDE.getCode()) {
            // 只需要校验对方是否在黑名单
            LambdaQueryWrapper<FriendshipEntity> wrapperForSingleSide = Wrappers.lambdaQuery(FriendshipEntity.class)
                    .eq(FriendshipEntity::getAppId, req.getAppId())
                    .eq(FriendshipEntity::getFromId, req.getFromId())
                    .in(FriendshipEntity::getToId, req.getToIds());
            List<FriendshipEntity> singleSideList = this.list(wrapperForSingleSide);
            for (FriendshipEntity entity : singleSideList) {
                CheckBlackResp resp = new CheckBlackResp();
                resp.setToId(entity.getToId());
                resp.setBlackRelationType(
                        entity.getBlack() == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode() ?
                                BlackRelationType.A2B.getCode() : BlackRelationType.NONE.getCode());
                respList.add(resp);
            }
        } else {
            // 双向校验比较复杂
            LambdaQueryWrapper<FriendshipEntity> wrapperForward = Wrappers.lambdaQuery(FriendshipEntity.class)
                    .eq(FriendshipEntity::getAppId, req.getAppId())
                    .eq(FriendshipEntity::getFromId, req.getFromId())
                    .in(FriendshipEntity::getToId, req.getToIds());
            List<FriendshipEntity> forwardList = this.list(wrapperForward);

            LambdaQueryWrapper<FriendshipEntity> wrapperBackward = Wrappers.lambdaQuery(FriendshipEntity.class)
                    .eq(FriendshipEntity::getAppId, req.getAppId())
                    .in(FriendshipEntity::getFromId, req.getToIds())
                    .eq(FriendshipEntity::getToId, req.getFromId());
            List<FriendshipEntity> backwardList = this.list(wrapperBackward);

            // 将backwardList转换成map方便校验
            Map<Long, FriendshipEntity> backwardMap = backwardList.stream().collect(Collectors.toMap(FriendshipEntity::getFromId, a -> a));
            // 以from方向校验
            for (FriendshipEntity entity : forwardList) {
                CheckBlackResp resp = new CheckBlackResp();
                resp.setToId(entity.getToId());
                Integer forwardType = entity.getBlack();
                // 反向查看
                Integer backwardType = FriendshipStatusEnum.BLACK_STATUS_NO_BLACK.getCode();
                FriendshipEntity friendEntity = backwardMap.get(entity.getToId());
                if (friendEntity != null) {
                    backwardType = friendEntity.getBlack();
                }
                if (forwardType == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode() && backwardType == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode()) {
                    resp.setBlackRelationType(BlackRelationType.ALL.getCode());
                } else if (forwardType == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode()) {
                    resp.setBlackRelationType(BlackRelationType.A2B.getCode());
                } else if (backwardType == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode()) {
                    resp.setBlackRelationType(BlackRelationType.B2A.getCode());
                }
                if (forwardType == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode() || backwardType == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode()) {
                    respList.add(resp);
                }
            }
            // 以to方向校验
            Set<Long> toSetByFrom = forwardList.stream().map(FriendshipEntity::getToId).collect(Collectors.toSet());
            Set<Long> fromSetByTo = backwardMap.keySet();
            Set<Long> diffSet = new HashSet<>(fromSetByTo);
            diffSet.removeAll(toSetByFrom);
            for (Long toId : diffSet) {
                FriendshipEntity toEntity = backwardMap.get(toId);
                if (toEntity.getStatus() == FriendshipStatusEnum.BLACK_STATUS_BLACKED.getCode()) {
                    CheckBlackResp resp = new CheckBlackResp();
                    resp.setToId(toId);
                    resp.setBlackRelationType(BlackRelationType.B2A.getCode());
                    respList.add(resp);
                }
            }

        }
        return respList;
    }

    @Transactional
    public void doAddFriend(Integer appId, Long fromId, FriendshipDto dto) {
        // A-B
        // 插入两条记录
        // 查询记录是否存在，如果存在则判断状态，如果已添加则提示已添加，如果未添加则修改状态。
        LambdaQueryWrapper<FriendshipEntity> fromQuery = Wrappers.lambdaQuery(FriendshipEntity.class)
                .eq(FriendshipEntity::getAppId, appId)
                .eq(FriendshipEntity::getFromId, fromId)
                .eq(FriendshipEntity::getToId, dto.getToId());
        Optional<FriendshipEntity> fromOpt = this.unique(fromQuery);
        if (!fromOpt.isPresent()) {
            FriendshipEntity fromEntity = BeanUtil.sourceToTarget(dto, FriendshipEntity.class);
            fromEntity.setId(IdWorker.getId());
            fromEntity.setStatus(FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode());
            fromEntity.setBlack(FriendshipStatusEnum.BLACK_STATUS_NO_BLACK.getCode());
            if (!insert(fromEntity)) {
                throw new ApplicationException(ImServiceCode.ADD_FRIENDSHIP_FAIL, "好有添加失败");
            }
        } else {
            if (fromOpt.get().getStatus() == FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode()) {
                // 返回已添加
                throw new ApplicationException(ImServiceCode.ADD_FRIENDSHIP_EXIST, "对方已经是你好友");
            }
            if (fromOpt.get().getStatus() == FriendshipStatusEnum.FRIEND_STATUS_DELETE.getCode()) {
                // 返回已删除，则需要修改状态为已添加，并且更新资料数据
                FriendshipEntity updateEntity = new FriendshipEntity();
                if (StringUtils.isNotBlank(dto.getAddSource())) {
                    updateEntity.setAddSource(dto.getAddSource());
                }
                if (StringUtils.isNotBlank(dto.getRemark())) {
                    updateEntity.setRemark(dto.getRemark());
                }
                if (StringUtils.isNotBlank(dto.getExtra())) {
                    updateEntity.setExtra(dto.getExtra());
                }
                updateEntity.setStatus(FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode());
                if (!this.update(updateEntity, fromQuery)) {
                    throw new ApplicationException(ImServiceCode.ADD_FRIENDSHIP_FAIL, "好有添加失败");
                }
            }
        }
        LambdaQueryWrapper<FriendshipEntity> toQuery = Wrappers.lambdaQuery(FriendshipEntity.class)
                .eq(FriendshipEntity::getAppId, appId)
                .eq(FriendshipEntity::getFromId, dto.getToId())
                .eq(FriendshipEntity::getToId, fromId);
        Optional<FriendshipEntity> toOpt = this.unique(fromQuery);
        if (!toOpt.isPresent()) {
            FriendshipEntity toEntity = BeanUtil.sourceToTarget(dto, FriendshipEntity.class);
            toEntity.setId(IdWorker.getId());
            toEntity.setFromId(dto.getToId());
            toEntity.setToId(fromId);
            toEntity.setStatus(FriendshipStatusEnum.FRIEND_STATUS_NORMAL.getCode());
            toEntity.setBlack(FriendshipStatusEnum.BLACK_STATUS_NO_BLACK.getCode());
            if (!insert(toEntity)) {
                throw new ApplicationException(ImServiceCode.ADD_FRIENDSHIP_FAIL, "好有添加失败");
            }
        }
    }

    @Transactional
    public void doUpdateFriend(Integer appId, Long fromId, FriendshipDto dto) {
        LambdaUpdateWrapper<FriendshipEntity> updateWrapper = Wrappers.lambdaUpdate(FriendshipEntity.class)
                .set(StringUtils.isNotBlank(dto.getAddSource()), FriendshipEntity::getAddSource, dto.getAddSource())
                .set(StringUtils.isNotBlank(dto.getExtra()), FriendshipEntity::getExtra, dto.getExtra())
                .set(StringUtils.isNotBlank(dto.getRemark()), FriendshipEntity::getRemark, dto.getRemark())
                .eq(FriendshipEntity::getAppId, appId)
                .eq(FriendshipEntity::getFromId, fromId)
                .eq(FriendshipEntity::getToId, dto.getToId());
        if (!this.upldate(updateWrapper)) {
            throw new ApplicationException(ImServiceCode.UPDATE_FRIENDSHIP_FAIL);
        }
    }
}
