package com.wb.imall.service.model.resp;

import com.wb.imall.common.model.AbstractResponse;
import lombok.Data;

@Data
public class FriendshipRequestResp extends AbstractResponse {
    /**
     * from_id
     */
    private Long fromId;

    /**
     * to_id
     */
    private Long toId;

    /**
     * 备注
     */
    private String remark;

    /**
     * 是否已读 1已读
     */
    private Integer readStatus;

    /**
     * 好友来源
     */
    private String addSource;

    /**
     * 好友验证信息
     */
    private String addWording;

    /**
     * 审批状态 1同意 2拒绝
     */
    private Integer approveStatus;

    private Long sequence;
}
