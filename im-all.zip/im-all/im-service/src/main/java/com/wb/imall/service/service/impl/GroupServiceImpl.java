package com.wb.imall.service.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.util.BeanUtil;
import com.wb.imall.common.util.WrapperUtil;
import com.wb.imall.service.entity.GroupEntity;
import com.wb.imall.service.enums.GroupMemberRole;
import com.wb.imall.service.enums.GroupStatus;
import com.wb.imall.service.enums.GroupType;
import com.wb.imall.service.enums.ImServiceCode;
import com.wb.imall.service.mapper.GroupDao;
import com.wb.imall.service.model.req.CreateGroupReq;
import com.wb.imall.service.model.req.DestroyGroupReq;
import com.wb.imall.service.model.req.GetGroupInfoReq;
import com.wb.imall.service.model.req.GetGroupMemberReq;
import com.wb.imall.service.model.req.GroupMemberDto;
import com.wb.imall.service.model.req.ImportGroupReq;
import com.wb.imall.service.model.req.TransferGroupReq;
import com.wb.imall.service.model.req.UpdateGroupMemberRoleReq;
import com.wb.imall.service.model.req.UpdateGroupReq;
import com.wb.imall.service.model.resp.GetRoleInGroupResp;
import com.wb.imall.service.model.resp.GroupResp;
import com.wb.imall.service.service.GroupMemberService;
import com.wb.imall.service.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@Service
public class GroupServiceImpl extends BaseServiceImpl<GroupDao, GroupEntity> implements GroupService {
    @Autowired
    private GroupMemberService groupMemberService;

    @Override
    public void importGroup(ImportGroupReq req) {
        GroupEntity entity = BeanUtil.sourceToTarget(req, GroupEntity.class);
        entity.setId(IdWorker.getId());
        if (entity.getStatus() == null) {
            entity.setStatus(GroupStatus.NORMAL.getCode());
        }
        boolean ins = this.insert(entity);
        if (!ins) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "导入群组失败");
        }
    }

    @Override
    public void updateGroup(UpdateGroupReq req) {
        Optional<GroupEntity> grpOpt = this.unique(req.getAppId(), req.getId());
        if (!grpOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群组不存在");
        }
        GroupEntity grpInDb = grpOpt.get();
        boolean isAdmin = false;
        if (!isAdmin) {
            // 校验权限
            GetRoleInGroupResp roleInGroup = groupMemberService.getRoleInGroup(req.getAppId(), req.getId(), req.getOperatorId());
            if (roleInGroup == null) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群成员不存在");
            }
            boolean isManager = roleInGroup.getRole() == GroupMemberRole.MEMBER.getCode();
            boolean isOwner = roleInGroup.getRole() == GroupMemberRole.OWNER.getCode();
            if (grpInDb.getGroupType() == GroupType.PUBLIC.getCode()) {
                // public group allow update by owner.
                isAdmin = isOwner || isManager;
            }
        }
        if (!isAdmin) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "此操作只支持群主或管理员");
        }
        GroupEntity entity = BeanUtil.sourceToTarget(req, GroupEntity.class);
        boolean ret = this.update(entity, WrapperUtil.queryWithAppId(GroupEntity.class, req.getAppId()).eq(GroupEntity::getId, req.getId()));
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群组更新失败");
        }
    }

    @Transactional
    @Override
    public void createGroup(CreateGroupReq req) {
        boolean isAdmin = false;
        if (!isAdmin) {
            req.setOwnerId(req.getOperatorId());
        }

        GroupEntity entity = BeanUtil.sourceToTarget(req, GroupEntity.class);
        if (req.getGroupType() == GroupType.PUBLIC.getCode() && req.getOwnerId() == null) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "公开群必须指定群主");
        }
        // 新增群
        entity.setId(IdWorker.getId());
        boolean ret = this.insert(entity);
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "新增群组失败");
        }
        // 新增群主
        GroupMemberDto groupMemberDto = new GroupMemberDto();
        groupMemberDto.setAppId(req.getAppId());
        groupMemberDto.setMemberId(req.getOwnerId());
        groupMemberDto.setRole(GroupMemberRole.OWNER.getCode());
        groupMemberDto.setJoinTime(System.currentTimeMillis());
        groupMemberService.addGroupMember(req.getAppId(), entity.getId(), groupMemberDto);

        // 新增群成员
        List<GroupMemberDto> members = req.getMembers();
        if (CollectionUtil.isNotEmpty(members)) {
            for (GroupMemberDto dto : members) {
                groupMemberService.addGroupMember(req.getAppId(), entity.getId(), groupMemberDto);
            }
        }
    }

    @Override
    public GroupResp getGroup(GetGroupInfoReq req) {
        Optional<GroupEntity> entityOpt = this.unique(req.getAppId(), req.getId());
        if (!entityOpt.isPresent()) {
            return null;
        }
        GroupEntity entity = entityOpt.get();
        GroupResp resp = BeanUtil.sourceToTarget(entity, GroupResp.class);
        return resp;
    }

    @Override
    public void destroy(DestroyGroupReq req) {
        boolean isAdmin = false;
        Optional<GroupEntity> groupOpt = this.unique(req.getAppId(), req.getGroupId());
        if (!groupOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群组不存在");
        }
        GroupEntity groupEntity = groupOpt.get();

        if (!isAdmin) {
            // 非管理员不能删除私有群
            if (groupEntity.getGroupType() == GroupType.PRIVATE.getCode()) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "不允许解散");
            }
            if (groupEntity.getGroupType() == GroupType.PUBLIC.getCode()
                    && !groupEntity.getOwnerId().equals(req.getOperatorId())) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "不允许解散");
            }
        }
        GroupEntity update = new GroupEntity();
        update.setStatus(GroupStatus.DESTORY.getCode());
        boolean ret = this.update(update, WrapperUtil.queryWithAppId(GroupEntity.class, req.getAppId()).eq(GroupEntity::getId, groupEntity.getId()));
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "解散失败");
        }
    }

    @Transactional
    @Override
    public void transfer(TransferGroupReq req) {
        Optional<GroupEntity> groupOpt = this.unique(req.getAppId(), req.getGroupId());
        if (!groupOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群组不存在");
        }
        GetGroupMemberReq getGroupMemberReq = new GetGroupMemberReq();
        getGroupMemberReq.setAppId(req.getAppId());
        getGroupMemberReq.setGroupId(req.getGroupId());
        getGroupMemberReq.setMemberId(req.getMemberId());
        getGroupMemberReq.setOperatorId(req.getOperatorId());
        GroupMemberDto groupMemberDto = groupMemberService.getGroupMemberInfo(getGroupMemberReq);
        if (groupMemberDto == null) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "操作人不是群成员");
        }
        if (groupMemberDto.getRole() != GroupMemberRole.OWNER.getCode()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "操作人不是群主");
        }

        GetGroupMemberReq toGetGroupMemberReq = new GetGroupMemberReq();
        toGetGroupMemberReq.setAppId(req.getAppId());
        toGetGroupMemberReq.setGroupId(req.getGroupId());
        toGetGroupMemberReq.setMemberId(req.getToMemberId());
        toGetGroupMemberReq.setOperatorId(req.getOperatorId());
        GroupMemberDto toGroupMemberDto = groupMemberService.getGroupMemberInfo(toGetGroupMemberReq);
        if (toGroupMemberDto == null) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "群内无此人");
        }
        GroupEntity updateGroup = new GroupEntity();
        updateGroup.setOwnerId(req.getToMemberId());
        boolean ret = this.update(updateGroup, WrapperUtil.queryWithAppId(GroupEntity.class, req.getAppId()).eq(GroupEntity::getId, req.getGroupId()));
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "转让失败");
        }

        UpdateGroupMemberRoleReq req1 = new UpdateGroupMemberRoleReq();
        req1.setAppId(req.getAppId());
        req1.setOperatorId(req.getOperatorId());
        req1.setGroupId(req.getGroupId());
        req1.setMemberId(req.getMemberId());
        req1.setRole(GroupMemberRole.MEMBER.getCode());
        groupMemberService.updateGroupMemberRole(req1);

        UpdateGroupMemberRoleReq req2 = new UpdateGroupMemberRoleReq();
        req2.setAppId(req.getAppId());
        req2.setOperatorId(req.getOperatorId());
        req2.setGroupId(req.getGroupId());
        req2.setMemberId(req.getToMemberId());
        req2.setRole(GroupMemberRole.OWNER.getCode());
        groupMemberService.updateGroupMemberRole(req2);

    }
}
