package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import com.wb.imall.common.model.PagedRequest;
import lombok.Data;

@Data
public class ReadFriendRequestReq extends PagedRequest {
    private Long fromId;
}
