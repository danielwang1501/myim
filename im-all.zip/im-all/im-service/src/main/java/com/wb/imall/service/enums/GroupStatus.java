package com.wb.imall.service.enums;

public enum GroupStatus {
    NORMAL(0),
    DESTORY(1)
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    GroupStatus(int code) {
        this.code = code;
    }
}
