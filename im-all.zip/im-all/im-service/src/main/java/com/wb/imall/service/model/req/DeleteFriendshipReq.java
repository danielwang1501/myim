package com.wb.imall.service.model.req;

import com.wb.imall.common.model.AbstractRequest;
import lombok.Data;

@Data
public class DeleteFriendshipReq extends AbstractRequest {
    private Integer fromId;
    private Integer toId;
}
