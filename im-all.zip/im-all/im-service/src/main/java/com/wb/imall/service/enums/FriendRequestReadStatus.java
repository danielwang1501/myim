package com.wb.imall.service.enums;

public enum FriendRequestReadStatus {
    UNREAD(0),
    READ(1),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    FriendRequestReadStatus(int code) {
        this.code = code;
    }
}
