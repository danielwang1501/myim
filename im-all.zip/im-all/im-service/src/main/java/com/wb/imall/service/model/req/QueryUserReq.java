package com.wb.imall.service.model.req;

import com.wb.imall.common.model.RequestBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class QueryUserReq extends RequestBase {
}
