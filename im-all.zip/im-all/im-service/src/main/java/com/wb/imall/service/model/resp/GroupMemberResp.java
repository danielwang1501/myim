package com.wb.imall.service.model.resp;

import com.wb.imall.common.model.AbstractResponse;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class GroupMemberResp extends AbstractResponse {
    private Long memberId;
    private LocalDateTime speakDate;
    private Integer role;
    private String alias;
    private Integer joinType;
    private Long joinTime;
}
