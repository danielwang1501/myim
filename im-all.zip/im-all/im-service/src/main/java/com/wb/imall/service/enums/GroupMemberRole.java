package com.wb.imall.service.enums;

public enum GroupMemberRole {
    MEMBER(0),
    MANAGER(1),
    OWNER(2),
    MUTE(3),
    LEAVE(4)
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    GroupMemberRole(int code) {
        this.code = code;
    }
}
