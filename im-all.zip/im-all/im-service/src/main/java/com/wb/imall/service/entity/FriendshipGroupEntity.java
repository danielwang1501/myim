package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-20
 */
@TableName("im_friendship_group")
public class FriendshipGroupEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * from_id
     */
    @TableField("from_id")
    private String fromId;

    @TableField("group_name")
    private String groupName;

    @TableField("sequence")
    private Long sequence;


    public String getFromId() {
        return fromId;
    }

    public void setFromId(String fromId) {
        this.fromId = fromId;
    }
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }

    @Override
    public String toString() {
        return "FriendshipGroupEntity{" +
            ", fromId=" + fromId +
            ", groupName=" + groupName +
            ", sequence=" + sequence +
        "}";
    }
}
