package com.wb.imall.service.enums;

public enum FriendRequestApproveStatus {
    INITIAL(0),
    AGREE(1),
    REJECT(2),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    FriendRequestApproveStatus(int code) {
        this.code = code;
    }
}
