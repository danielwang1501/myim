package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-19
 */
@TableName("im_friendship_request")
public class FriendshipRequestEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * from_id
     */
    @TableField("from_id")
    private Long fromId;

    /**
     * to_id
     */
    @TableField("to_id")
    private Long toId;

    /**
     * 备注
     */
    @TableField("remark")
    private String remark;

    /**
     * 是否已读 1已读
     */
    @TableField("read_status")
    private Integer readStatus;

    /**
     * 好友来源
     */
    @TableField("add_source")
    private String addSource;

    /**
     * 好友验证信息
     */
    @TableField("add_wording")
    private String addWording;

    /**
     * 审批状态 1同意 2拒绝
     */
    @TableField("approve_status")
    private Integer approveStatus;

    @TableField("sequence")
    private Long sequence;


    public Long getFromId() {
        return fromId;
    }

    public void setFromId(Long fromId) {
        this.fromId = fromId;
    }
    public Long getToId() {
        return toId;
    }

    public void setToId(Long toId) {
        this.toId = toId;
    }
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    public Integer getReadStatus() {
        return readStatus;
    }

    public void setReadStatus(Integer readStatus) {
        this.readStatus = readStatus;
    }
    public String getAddSource() {
        return addSource;
    }

    public void setAddSource(String addSource) {
        this.addSource = addSource;
    }
    public String getAddWording() {
        return addWording;
    }

    public void setAddWording(String addWording) {
        this.addWording = addWording;
    }
    public Integer getApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(Integer approveStatus) {
        this.approveStatus = approveStatus;
    }

    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }

    @Override
    public String toString() {
        return "FriendshipRequestEntity{" +
            ", fromId=" + fromId +
            ", toId=" + toId +
            ", remark=" + remark +
            ", readStatus=" + readStatus +
            ", addSource=" + addSource +
            ", addWording=" + addWording +
            ", approveStatus=" + approveStatus +
            ", sequence=" + sequence +
        "}";
    }
}
