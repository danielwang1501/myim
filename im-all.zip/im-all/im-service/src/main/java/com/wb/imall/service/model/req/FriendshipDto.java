package com.wb.imall.service.model.req;

import lombok.Data;

@Data
public class FriendshipDto {
    private Long toId;
    private String remark;
    private String addSource;
    private String extra;
    private String addWording;
}
