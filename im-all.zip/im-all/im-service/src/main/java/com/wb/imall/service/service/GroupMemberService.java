package com.wb.imall.service.service;

import cn.hutool.core.lang.Pair;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.service.entity.GroupMemberEntity;
import com.wb.imall.service.model.req.GetJoinedGroupReq;
import com.wb.imall.service.model.req.GetGroupMemberReq;
import com.wb.imall.service.model.req.GroupMemberDto;
import com.wb.imall.service.model.req.ImportGroupMemberReq;
import com.wb.imall.service.model.req.QueryGroupMemberReq;
import com.wb.imall.service.model.req.UpdateGroupMemberRoleReq;
import com.wb.imall.service.model.resp.AddMemberResp;
import com.wb.imall.service.model.resp.GetRoleInGroupResp;
import com.wb.imall.service.model.resp.GroupMemberResp;
import com.wb.imall.service.model.resp.GroupResp;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
public interface GroupMemberService extends BaseService<GroupMemberEntity> {
    List<AddMemberResp> importGroupMember(ImportGroupMemberReq req);

    void addGroupMember(Integer appId, Long groupId, GroupMemberDto dto);

    GetRoleInGroupResp getRoleInGroup(Integer appId, Long groupId, Long memberId);

    Pair<List<GroupMemberResp>, Long> queryGroupMember(QueryGroupMemberReq req);

    List<GroupResp> getJoinedGroup(GetJoinedGroupReq req);

    GroupMemberDto getGroupMemberInfo(GetGroupMemberReq req);
    void updateGroupMemberRole(UpdateGroupMemberRoleReq req);

}
