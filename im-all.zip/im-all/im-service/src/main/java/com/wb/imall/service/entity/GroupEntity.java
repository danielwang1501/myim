package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@TableName("im_group")
public class GroupEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;



    /**
     * 群主	
     */
    @TableField("owner_id")
    private Long ownerId;

    /**
     * 群类型 1私有群（类似微信） 2公开群(类似qq）
     */
    @TableField("group_type")
    private Integer groupType;

    @TableField("group_name")
    private String groupName;

    /**
     * 是否全员禁言，0 不禁言；1 全员禁言
     */
    @TableField("mute")
    private Integer mute;

    /**
     * //    申请加群选项包括如下几种：	//    0 表示禁止任何人申请加入	//    1 表示需要群主或管理员审批	//    2 表示允许无需审批自由加入群组
     */
    @TableField("apply_join_type")
    private Integer applyJoinType;

    @TableField("photo")
    private String photo;

    @TableField("max_member_count")
    private Integer maxMemberCount;

    /**
     * 群简介
     */
    @TableField("introduction")
    private String introduction;

    /**
     * 群公告
     */
    @TableField("notification")
    private String notification;

    /**
     * 群状态 0正常 1解散
     */
    @TableField("status")
    private Integer status;

    @TableField("sequence")
    private Long sequence;

    @TableField("create_time")
    private Long createTime;

    /**
     * 来源
     */
    @TableField("extra")
    private String extra;

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }
    public Integer getGroupType() {
        return groupType;
    }

    public void setGroupType(Integer groupType) {
        this.groupType = groupType;
    }
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public Integer getMute() {
        return mute;
    }

    public void setMute(Integer mute) {
        this.mute = mute;
    }
    public Integer getApplyJoinType() {
        return applyJoinType;
    }

    public void setApplyJoinType(Integer applyJoinType) {
        this.applyJoinType = applyJoinType;
    }
    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
    public Integer getMaxMemberCount() {
        return maxMemberCount;
    }

    public void setMaxMemberCount(Integer maxMemberCount) {
        this.maxMemberCount = maxMemberCount;
    }
    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }
    public String getNotification() {
        return notification;
    }

    public void setNotification(String notification) {
        this.notification = notification;
    }
    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }
    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    @Override
    public String toString() {
        return "GroupEntity{" +
            "ownerId=" + ownerId +
            ", groupType=" + groupType +
            ", groupName=" + groupName +
            ", mute=" + mute +
            ", applyJoinType=" + applyJoinType +
            ", photo=" + photo +
            ", maxMemberCount=" + maxMemberCount +
            ", introduction=" + introduction +
            ", notification=" + notification +
            ", status=" + status +
            ", sequence=" + sequence +
            ", createTime=" + createTime +
            ", extra=" + extra +
        "}";
    }
}
