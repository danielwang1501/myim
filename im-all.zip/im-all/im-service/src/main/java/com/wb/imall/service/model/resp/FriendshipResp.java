package com.wb.imall.service.model.resp;

import com.wb.imall.common.model.AbstractResponse;

public class FriendshipResp extends AbstractResponse {
    /**
     * from_id
     */
    private Long fromId;

    /**
     * to_id
     */
    private Long toId;

    /**
     * 备注
     */
    private String remark;

    /**
     * 状态 1正常 2删除
     */
    private Integer status;

    /**
     * 1正常 2拉黑
     */
    private Integer black;

    private Long createTime;

    private Long friendSequence;

    private Long blackSequence;

    /**
     * 来源
     */
    private String addSource;

    /**
     * 来源
     */
    private String extra;
}
