package com.wb.imall.service.controller;


import com.wb.imall.common.R;
import com.wb.imall.service.model.req.ApproveFriendRequestReq;
import com.wb.imall.service.service.FriendshipRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-19
 */
@RestController
@RequestMapping("/friendshipReq")
public class FriendshipRequestController {
    @Autowired
    private FriendshipRequestService friendshipRequestService;

    @PostMapping("/approve")
    public R approve(@RequestBody ApproveFriendRequestReq req) {
        friendshipRequestService.approve(req);
        return R.ok();
    }
}
