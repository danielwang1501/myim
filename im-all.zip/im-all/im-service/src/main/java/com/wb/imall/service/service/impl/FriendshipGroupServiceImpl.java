package com.wb.imall.service.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.util.BeanUtil;
import com.wb.imall.common.util.WrapperUtil;
import com.wb.imall.service.entity.FriendshipGroupEntity;
import com.wb.imall.service.enums.ImServiceCode;
import com.wb.imall.service.mapper.FriendshipGroupDao;
import com.wb.imall.service.model.req.AddAndDeleteFriendshipGroupMemberReq;
import com.wb.imall.service.model.req.AddFriendshipGroupReq;
import com.wb.imall.service.model.req.DelFriendshipGroupReq;
import com.wb.imall.service.service.FriendshipGroupMemberService;
import com.wb.imall.service.service.FriendshipGroupService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-20
 */
@Service
public class FriendshipGroupServiceImpl extends BaseServiceImpl<FriendshipGroupDao, FriendshipGroupEntity> implements FriendshipGroupService {

    @Autowired
    private FriendshipGroupMemberService friendshipGroupMemberService;

    @Transactional
    @Override
    public void addGroup(AddFriendshipGroupReq req) {
        LambdaQueryWrapper<FriendshipGroupEntity> queryWrapper = Wrappers.lambdaQuery(FriendshipGroupEntity.class)
                .eq(FriendshipGroupEntity::getAppId, req.getAppId())
                .eq(FriendshipGroupEntity::getGroupName, req.getGroupName())
                .eq(FriendshipGroupEntity::getFromId, req.getFromId());
        Optional<FriendshipGroupEntity> entityOpt = this.unique(queryWrapper);
        if (entityOpt.isPresent()) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有分组已存在");
        }
        FriendshipGroupEntity entity = BeanUtil.sourceToTarget(req, FriendshipGroupEntity.class);
        long friendshipGroupId = IdWorker.getId();
        try {
            entity.setId(friendshipGroupId);
            boolean ins = this.insert(entity);
            if (!ins) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有分组已存在");
            }
        } catch (Exception e) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有分组已存在");
        }

        if (CollectionUtil.isEmpty(req.getToIds())) {
            return;
        }
        AddAndDeleteFriendshipGroupMemberReq addAndDeleteFriendshipGroupMemberReq = new AddAndDeleteFriendshipGroupMemberReq();
        addAndDeleteFriendshipGroupMemberReq.setGroupId(friendshipGroupId);
        addAndDeleteFriendshipGroupMemberReq.setToIds(req.getToIds());
        addAndDeleteFriendshipGroupMemberReq.setAppId(req.getAppId());
        friendshipGroupMemberService.add(addAndDeleteFriendshipGroupMemberReq);
    }

    @Transactional
    @Override
    public void deleteGroup(DelFriendshipGroupReq req) {
        Long groupId = 0L;
        boolean ret = false;
        if (Objects.nonNull(req.getGroupId()) && req.getGroupId() > 0) {
            // 根据ID删除
            Optional<FriendshipGroupEntity> entityOpt = this.unique(req.getAppId(), req.getGroupId());
            if (!entityOpt.isPresent()) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "分组不存在");
            }
            groupId = req.getGroupId();
            ret = this.removeById(req.getGroupId());

        } else if (StringUtils.isNoneBlank(req.getGroupName())) {
            // 根据分组名删除
            LambdaQueryWrapper<FriendshipGroupEntity> queryWrapper = WrapperUtil.queryWithAppId(FriendshipGroupEntity.class, req.getAppId())
                    .eq(FriendshipGroupEntity::getGroupName, req.getGroupName())
                    .eq(FriendshipGroupEntity::getFromId, req.getFromId());
            FriendshipGroupEntity entity = getOne(queryWrapper);
            if (Objects.isNull(entity)) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "分组不存在");
            }
            ret = this.remove(queryWrapper);
            groupId = entity.getId();
        } else {
            //
        }
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "删除好有分组失败");
        }
        // 删除分组用户数据
        friendshipGroupMemberService.deleteGroupMember(req.getAppId(), groupId);
    }
}
