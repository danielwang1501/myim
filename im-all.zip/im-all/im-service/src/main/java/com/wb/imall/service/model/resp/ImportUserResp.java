package com.wb.imall.service.model.resp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class ImportUserResp {
    private List<String> successIds = new ArrayList<>();
    private List<String> errorIds = new ArrayList<>();
}
