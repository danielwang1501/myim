package com.wb.imall.service.enums;

public enum GroupType {
    PUBLIC(1),
    PRIVATE(2);
    private int code;

    public Integer getCode() {
        return this.code;
    }

    GroupType(int code) {
        this.code = code;
    }
}
