package com.wb.imall.service.controller;


import com.wb.imall.common.R;
import com.wb.imall.service.model.req.AddOrRemoveBlackReq;
import com.wb.imall.service.model.req.AddFriendReq;
import com.wb.imall.service.model.req.CheckBlackReq;
import com.wb.imall.service.model.req.CheckFriendshipReq;
import com.wb.imall.service.model.req.DeleteFriendshipReq;
import com.wb.imall.service.model.req.ImportFriendshipReq;
import com.wb.imall.service.model.req.QueryFriendshipReq;
import com.wb.imall.service.model.req.UpdateFriendReq;
import com.wb.imall.service.model.resp.CheckBlackResp;
import com.wb.imall.service.model.resp.CheckFriendshipResp;
import com.wb.imall.service.model.resp.FriendshipResp;
import com.wb.imall.service.model.resp.ImportFriendshipResp;
import com.wb.imall.service.service.FriendshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-18
 */
@RestController
@RequestMapping("/friendship")
public class FriendshipController {

    @Autowired
    private FriendshipService friendshipService;

    @PostMapping("/import")
    public R<ImportFriendshipResp> importFriendship(@RequestBody ImportFriendshipReq req) {
        ImportFriendshipResp resp = friendshipService.importFriendship(req);
        return R.ok(resp);
    }

    @PostMapping("/add")
    public R add(@RequestBody AddFriendReq req) {
        boolean res = friendshipService.addFriend(req);
        if (!res) {
            return R.error();
        }
        return R.ok();
    }

    @PostMapping("/update")
    public R update(@RequestBody UpdateFriendReq req) {
        boolean res = friendshipService.updateFriend(req);
        if (!res) {
            return R.error();
        }
        return R.ok();
    }

    @PostMapping("/delete")
    public R delete(@RequestBody DeleteFriendshipReq req) {
        boolean res = friendshipService.deleteFriend(req);
        if (!res) {
            return R.error();
        }
        return R.ok();
    }

    @PostMapping("/deleteAll")
    public R deleteAll(@RequestBody DeleteFriendshipReq req) {
        boolean res = friendshipService.deleteFriend(req);
        if (!res) {
            return R.error();
        }
        return R.ok();
    }

    @PostMapping("/queryOne")
    public R queryOne(@RequestBody QueryFriendshipReq req) {
        FriendshipResp resp = friendshipService.queryOne(req);
        return R.ok(resp);
    }

    @PostMapping("/queryAll")
    public R queryAll(@RequestBody QueryFriendshipReq req) {
        List<FriendshipResp> resp = friendshipService.queryAll(req);
        return R.ok(resp);
    }

    @PostMapping("/checkFriendship")
    public R<List<CheckFriendshipResp>> checkFriendship(@RequestBody CheckFriendshipReq req) {
        List<CheckFriendshipResp> resp = friendshipService.checkFriendship(req);
        return R.ok(resp);
    }

    @PostMapping("/addBlack")
    public R addBlack(@RequestBody AddOrRemoveBlackReq req) {
        friendshipService.addBlack(req);
        return R.ok();
    }

    @PostMapping("/removeBlack")
    public R removeBlack(@RequestBody AddOrRemoveBlackReq req) {
        friendshipService.removeBlack(req);
        return R.ok();
    }

    @PostMapping("/checkBlack")
    public R<List<CheckBlackResp>> checkBlack(@RequestBody CheckBlackReq req) {
        List<CheckBlackResp> resp = friendshipService.checkBlack(req);
        return R.ok(resp);
    }

}
