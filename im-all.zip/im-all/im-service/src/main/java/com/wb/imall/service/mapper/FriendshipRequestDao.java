package com.wb.imall.service.mapper;

import com.wb.imall.service.entity.FriendshipRequestEntity;
import com.wb.imall.common.base.BaseDao;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-19
 */
@Mapper
public interface FriendshipRequestDao extends BaseDao<FriendshipRequestEntity> {

}
