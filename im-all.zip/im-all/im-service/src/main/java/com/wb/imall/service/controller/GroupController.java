package com.wb.imall.service.controller;


import com.wb.imall.common.R;
import com.wb.imall.service.model.req.CreateGroupReq;
import com.wb.imall.service.model.req.DestroyGroupReq;
import com.wb.imall.service.model.req.GetGroupInfoReq;
import com.wb.imall.service.model.req.ImportGroupReq;
import com.wb.imall.service.model.req.TransferGroupReq;
import com.wb.imall.service.model.req.UpdateGroupReq;
import com.wb.imall.service.model.resp.GroupResp;
import com.wb.imall.service.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@RestController
@RequestMapping("/grp")
public class GroupController {

    @Autowired
    private GroupService groupService;

    @PostMapping("import")
    public R importGroup(@RequestBody ImportGroupReq req) {
        groupService.importGroup(req);
        return R.ok();
    }

    @PostMapping("update")
    public R updateGroup(@RequestBody UpdateGroupReq req) {
        groupService.updateGroup(req);
        return R.ok();
    }

    @PostMapping("create")
    public R createGroup(@RequestBody CreateGroupReq req) {
        groupService.createGroup(req);
        return R.ok();
    }

    @PostMapping("getInfo")
    public R getGroup(@RequestBody GetGroupInfoReq req) {
        GroupResp group = groupService.getGroup(req);
        return R.ok(group);
    }

    @PostMapping("destroy")
    public R destroy(@RequestBody DestroyGroupReq req) {
        groupService.destroy(req);
        return R.ok();
    }

    @PostMapping("transfer")
    public R transfer(@RequestBody TransferGroupReq req) {
        groupService.transfer(req);
        return R.ok();
    }
}
