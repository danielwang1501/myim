package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-25
 */
@TableName("im_group_member")
public class GroupMemberEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * group_id
     */
    @TableField("group_id")
    private Long groupId;

    /**
     * 成员id	
     */
    @TableField("member_id")
    private Long memberId;

    /**
     * 群成员类型，0 普通成员, 1 管理员, 2 群主， 3 禁言，4 已经移除的成员
     */
    @TableField("role")
    private Integer role;

    @TableField("speak_date")
    private Long speakDate;

    /**
     * 是否全员禁言，0 不禁言；1 全员禁言
     */
    @TableField("mute")
    private Integer mute;

    /**
     * 群昵称
     */
    @TableField("alias")
    private String alias;

    /**
     * 加入时间
     */
    @TableField("join_time")
    private Long joinTime;

    /**
     * 离开时间
     */
    @TableField("leave_time")
    private Long leaveTime;

    /**
     * 加入类型
     */
    @TableField("join_type")
    private String joinType;

    @TableField("extra")
    private String extra;

    @TableField("create_time")
    private Long createTime;

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }
    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }
    public Long getSpeakDate() {
        return speakDate;
    }

    public void setSpeakDate(Long speakDate) {
        this.speakDate = speakDate;
    }
    public Integer getMute() {
        return mute;
    }

    public void setMute(Integer mute) {
        this.mute = mute;
    }
    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
    public Long getJoinTime() {
        return joinTime;
    }

    public void setJoinTime(Long joinTime) {
        this.joinTime = joinTime;
    }
    public Long getLeaveTime() {
        return leaveTime;
    }

    public void setLeaveTime(Long leaveTime) {
        this.leaveTime = leaveTime;
    }
    public String getJoinType() {
        return joinType;
    }

    public void setJoinType(String joinType) {
        this.joinType = joinType;
    }
    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }
    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "GroupMemberEntity{" +
            "groupId=" + groupId +
            ", memberId=" + memberId +
            ", role=" + role +
            ", speakDate=" + speakDate +
            ", mute=" + mute +
            ", alias=" + alias +
            ", joinTime=" + joinTime +
            ", leaveTime=" + leaveTime +
            ", joinType=" + joinType +
            ", extra=" + extra +
            ", createTime=" + createTime +
        "}";
    }
}
