package com.wb.imall.service.enums;

public enum FriendshipStatusEnum {
    FRIEND_STATUS_NO_FRIEND(0),
    FRIEND_STATUS_NORMAL(1),
    FRIEND_STATUS_DELETE(2),

    BLACK_STATUS_NO_BLACK(0),
    BLACK_STATUS_BLACKED(1),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    FriendshipStatusEnum(int code) {
        this.code = code;
    }
}
