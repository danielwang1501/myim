package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-18
 */
@TableName("im_friendship")
public class FriendshipEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * from_id
     */
    @TableField("from_id")
    private Long fromId;

    /**
     * to_id
     */
    @TableField("to_id")
    private Long toId;

    /**
     * 备注
     */
    @TableField("remark")
    private String remark;

    /**
     * 状态 1正常 2删除
     */
    @TableField("status")
    private Integer status;

    /**
     * 1正常 2拉黑
     */
    @TableField("black")
    private Integer black;

    @TableField("friend_sequence")
    private Long friendSequence;

    @TableField("black_sequence")
    private Long blackSequence;

    /**
     * 来源
     */
    @TableField("add_source")
    private String addSource;

    /**
     * 来源
     */
    @TableField("extra")
    private String extra;


    public Long getFromId() {
        return fromId;
    }

    public void setFromId(Long fromId) {
        this.fromId = fromId;
    }
    public Long getToId() {
        return toId;
    }

    public void setToId(Long toId) {
        this.toId = toId;
    }
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getBlack() {
        return black;
    }

    public void setBlack(Integer black) {
        this.black = black;
    }

    public Long getFriendSequence() {
        return friendSequence;
    }

    public void setFriendSequence(Long friendSequence) {
        this.friendSequence = friendSequence;
    }
    public Long getBlackSequence() {
        return blackSequence;
    }

    public void setBlackSequence(Long blackSequence) {
        this.blackSequence = blackSequence;
    }
    public String getAddSource() {
        return addSource;
    }

    public void setAddSource(String addSource) {
        this.addSource = addSource;
    }
    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    @Override
    public String toString() {
        return "FriendshipEntity{" +
            ", fromId=" + fromId +
            ", toId=" + toId +
            ", remark=" + remark +
            ", status=" + status +
            ", black=" + black +
            ", friendSequence=" + friendSequence +
            ", blackSequence=" + blackSequence +
            ", addSource=" + addSource +
            ", extra=" + extra +
        "}";
    }
}
