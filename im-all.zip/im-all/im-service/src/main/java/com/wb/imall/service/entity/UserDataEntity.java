package com.wb.imall.service.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.wb.imall.common.base.BaseEntity;

/**
 * <p>
 * 
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-05
 */
@TableName("im_user_data")
public class UserDataEntity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @TableField("user_id")
    private String userId;

    /**
     * 昵称
     */
    @TableField("nick_name")
    private String nickName;

    @TableField("password")
    private String password;

    @TableField("photo")
    private String photo;

    @TableField("user_sex")
    private Integer userSex;

    /**
     * 生日
     */
    @TableField("birth_day")
    private String birthDay;

    /**
     * 地址
     */
    @TableField("location")
    private String location;

    /**
     * 个性签名
     */
    @TableField("self_signature")
    private String selfSignature;

    /**
     * 加好友验证类型（Friend_AllowType） 1无需验证 2需要验证
     */
    @TableField("friend_allow_type")
    private Integer friendAllowType;

    /**
     * 禁用标识 1禁用
     */
    @TableField("forbidden_flag")
    private Integer forbiddenFlag;

    /**
     * 管理员禁止用户添加加好友：0 未禁用 1 已禁用
     */
    @TableField("disable_add_friend")
    private Integer disableAddFriend;

    /**
     * 禁言标识 1禁言
     */
    @TableField("silent_flag")
    private Integer silentFlag;

    /**
     * 用户类型 1普通用户 2客服 3机器人
     */
    @TableField("user_type")
    private Integer userType;

    @TableField("extra")
    private String extra;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
    public Integer getUserSex() {
        return userSex;
    }

    public void setUserSex(Integer userSex) {
        this.userSex = userSex;
    }
    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    public String getSelfSignature() {
        return selfSignature;
    }

    public void setSelfSignature(String selfSignature) {
        this.selfSignature = selfSignature;
    }
    public Integer getFriendAllowType() {
        return friendAllowType;
    }

    public void setFriendAllowType(Integer friendAllowType) {
        this.friendAllowType = friendAllowType;
    }
    public Integer getForbiddenFlag() {
        return forbiddenFlag;
    }

    public void setForbiddenFlag(Integer forbiddenFlag) {
        this.forbiddenFlag = forbiddenFlag;
    }
    public Integer getDisableAddFriend() {
        return disableAddFriend;
    }

    public void setDisableAddFriend(Integer disableAddFriend) {
        this.disableAddFriend = disableAddFriend;
    }
    public Integer getSilentFlag() {
        return silentFlag;
    }

    public void setSilentFlag(Integer silentFlag) {
        this.silentFlag = silentFlag;
    }
    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }
    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    @Override
    public String toString() {
        return "UserDataEntity{" +
            "userId=" + userId +
            ", nickName=" + nickName +
            ", password=" + password +
            ", photo=" + photo +
            ", userSex=" + userSex +
            ", birthDay=" + birthDay +
            ", location=" + location +
            ", selfSignature=" + selfSignature +
            ", friendAllowType=" + friendAllowType +
            ", forbiddenFlag=" + forbiddenFlag +
            ", disableAddFriend=" + disableAddFriend +
            ", silentFlag=" + silentFlag +
            ", userType=" + userType +
            ", extra=" + extra +
        "}";
    }
}
