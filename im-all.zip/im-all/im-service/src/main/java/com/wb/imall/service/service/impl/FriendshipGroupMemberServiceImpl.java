package com.wb.imall.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.wb.imall.common.base.BaseServiceImpl;
import com.wb.imall.common.exception.ApplicationException;
import com.wb.imall.common.util.WrapperUtil;
import com.wb.imall.service.entity.FriendshipGroupEntity;
import com.wb.imall.service.entity.FriendshipGroupMemberEntity;
import com.wb.imall.service.entity.UserDataEntity;
import com.wb.imall.service.enums.ImServiceCode;
import com.wb.imall.service.mapper.FriendshipGroupMemberDao;
import com.wb.imall.service.model.req.AddAndDeleteFriendshipGroupMemberReq;
import com.wb.imall.service.model.req.UserDto;
import com.wb.imall.service.service.FriendshipGroupMemberService;
import com.wb.imall.service.service.FriendshipGroupService;
import com.wb.imall.service.service.UserDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Daniel Wang
 * @since 2023-03-20
 */
@Service
public class FriendshipGroupMemberServiceImpl extends BaseServiceImpl<FriendshipGroupMemberDao, FriendshipGroupMemberEntity> implements FriendshipGroupMemberService {
    @Autowired
    private FriendshipGroupService friendshipGroupService;

    @Autowired
    private UserDataService userDataService;

    @Transactional
    @Override
    public void add(AddAndDeleteFriendshipGroupMemberReq req) {
        FriendshipGroupEntity groupEntity = friendshipGroupService.getById(req.getGroupId());
        if (Objects.isNull(groupEntity)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有分组不存在");
        }

        Long groupId = req.getGroupId();
        List<UserDto> userDtos = userDataService.queryList(req.getToIds());
        for (UserDto toUser : userDtos) {
            this.doAddGroupMember(groupId, toUser.getId());
        }
    }

    @Transactional
    @Override
    public Set<Long> doAddGroupMember(Long groupId, Long toId) {
        Set<Long> resp = new HashSet<>();
        FriendshipGroupMemberEntity entity = new FriendshipGroupMemberEntity();
        entity.setId(IdWorker.getId());
        entity.setGroupId(groupId);
        entity.setToId(toId);
        try {
            boolean ins = this.insert(entity);
            if (!ins) {
                throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "添加分组好友成员失败");
            }
            resp.add(entity.getId());
        } catch (Exception e) {
            e.printStackTrace();
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "添加分组好友成员失败");
        }
        return resp;
    }

    @Transactional
    @Override
    public void deleteGroupMember(Integer appId, Long groupId) {
        LambdaQueryWrapper<FriendshipGroupMemberEntity> queryWrapper = WrapperUtil.queryWithAppId(FriendshipGroupMemberEntity.class, appId);
        boolean ret = this.remove(queryWrapper);
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "删除分组好有失败");
        }
    }

    @Transactional
    @Override
    public void addGroupManager(AddAndDeleteFriendshipGroupMemberReq req) {
        FriendshipGroupEntity groupEntity = friendshipGroupService.getById(req.getGroupId());
        if (Objects.isNull(groupEntity)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有分组不存在");
        }
        List<UserDataEntity> userList = userDataService.listByIds(req.getToIds());
        for (UserDataEntity e : userList) {
            this.doAddGroupMember(req.getGroupId(), e.getId());
        }
    }

    @Override
    public void deleteGroupManager(AddAndDeleteFriendshipGroupMemberReq req) {
        FriendshipGroupEntity groupEntity = friendshipGroupService.getById(req.getGroupId());
        if (Objects.isNull(groupEntity)) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "好有分组不存在");
        }
        boolean ret = this.removeByIds(req.getToIds());
        if (!ret) {
            throw new ApplicationException(ImServiceCode.BUSINESS_LOGIC, "删除分组好有失败");
        }
    }

}
