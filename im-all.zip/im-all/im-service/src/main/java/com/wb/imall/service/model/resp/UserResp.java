package com.wb.imall.service.model.resp;

public class UserResp {
}
