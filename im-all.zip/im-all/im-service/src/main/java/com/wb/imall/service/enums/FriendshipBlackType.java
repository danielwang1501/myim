package com.wb.imall.service.enums;

public enum FriendshipBlackType {

    SINGLE_SIDE(1),
    DOUBLE_SIDE(2),
    ;
    private int code;

    public Integer getCode() {
        return this.code;
    }

    FriendshipBlackType(int code) {
        this.code = code;
    }
}
