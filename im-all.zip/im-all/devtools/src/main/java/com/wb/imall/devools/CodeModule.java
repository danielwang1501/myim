package com.wb.imall.devools;

import java.util.List;

import cn.hutool.core.util.StrUtil;

/**
 * @author fitz.yang
 * @version 2021.02
 * @since triton 2021.02
 */
public enum CodeModule {

    /**
     * 组织机构
     */
    User("user", "uc_", StrUtil.splitTrim("uc_organization,uc_permissions,uc_role,uc_user,uc_user_account,uc_user_affiliation,uc_user_login_account,uc_user_role,uc_user_tlog", ",")),
    /**
     * 基础公共模块
     */
    Comon("common", "sys_", StrUtil.splitTrim("sys_dict,sys_job_exector_log,sys_job_info,sys_job_log,sys_permissions,sys_proc,sys_proc_exec_log,sys_proc_log,sys_settings", ",")),
    ;

    private final String pkg;
    private final String tablePrefix;

    private final List<String> tables;

    CodeModule(String pkg, String tablePrefix, List<String> tables) {
        this.pkg = pkg;
        this.tablePrefix = tablePrefix;
        this.tables = tables;
    }

    public String getPkg() {
        return pkg;
    }

    public String getTablePrefix() {
        return tablePrefix;
    }

    public List<String> getTables() {
        return tables;
    }
}
