package com.wb.imall.devools;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import com.wb.imall.common.base.BaseEntity;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.common.base.BaseServiceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CodeGenerator {
    public static void main(String[] args) {
        List<String> tables = new ArrayList<>();
        tables.add("im_user_data");

        String projectPath = System.getProperty("user.dir");
        String rootPath = projectPath + "/scsi-basesaaa11111/bases-infraaaa";

        FastAutoGenerator.create("jdbc:mysql://192.168.33.21:3306/im-core?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai"
                , "root"
                , "Abc_123456")
                .globalConfig(builder -> {
                    builder.author("Daniel") // 设置代码的author
                            .commentDate("yyyy-MM-dd")
                            .outputDir(rootPath); // 指定输出目录
                })
                .packageConfig(builder -> {
                    builder.parent("com.wb.imall.service") // 设置父包名
//                            .moduleName("sys") // 设置父包模块名
                            .entity("entity")
                            .service("service")
                            .serviceImpl("service.impl")
                            .controller("controller")
                            .mapper("mapper")
                            .xml("mapper")
                            .pathInfo(Collections.singletonMap(OutputFile.mapperXml, System.getProperty("user.dir") + "\\src\\main\\resources\\mapper")); // 设置mapperXml生成路径
                })
                .strategyConfig(builder -> {
                    builder.addInclude("im_user_data") // 设置需要生成的表名
                            .addTablePrefix("im_")
                            .serviceBuilder() // 设置Service
                            // 设置service类名，%s适配表名
                            .formatServiceFileName("%sService")
                            // 设置impl类名，%s适配表名
                            .formatServiceImplFileName("%sServiceImpl")
                            .superServiceClass(BaseService.class)
                            .superServiceImplClass(BaseServiceImpl.class)
                            // entity实体类策略配置
                            .entityBuilder()
                            .superClass(BaseEntity.class)
                            .addSuperEntityColumns("id", "version", "is_deleted", "creation_time", "update_time")
                            .formatFileName("%sEntity")

                    ;

                })
                .templateEngine(new FreemarkerTemplateEngine()) // 使用Freemarker引擎模板，默认的是Velocity引擎模板
                .execute();
    }
}
