package com.wb.imall.devools;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.converts.MySqlTypeConvert;
import com.baomidou.mybatisplus.generator.config.querys.MySqlQuery;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import com.baomidou.mybatisplus.generator.keywords.MySqlKeyWordsHandler;
import com.wb.imall.common.base.BaseDao;
import com.wb.imall.common.base.BaseEntity;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.common.base.BaseServiceImpl;

import java.util.Arrays;
import java.util.Collections;


/**
 * @author fitz.yang
 * @version 2021.02
 * @since triton 2021.02
 */
public class CodeGenerateTool {


    public static void main(String[] args) {
//        genCode(CodeModule.User);
//        genCodeByTables(new String[]{"b_customer_authentication","b_customer_base","b_customer_house","b_house_adjustment","b_house_base","b_member_base","b_space_base","b_customer_base_extra"}, "b_", "bases");
        genCodeByTables(new String[]{"im_friendship"}, "im_", "com.wb.imall");

    }

    private static void genCode(CodeModule codeModule) {
        String[] tables = codeModule.getTables().toArray(new String[]{});
        String tablePrefix = codeModule.getTablePrefix();
        String codePackage = codeModule.getPkg();
        genCodeByTables(tables, tablePrefix, codePackage);
    }

    private static void genCodeByTables(String[] tables, String tablePrefix, String codePackage) {
        // 数据库连接
        DataSourceConfig dataSourceConfig =
                new DataSourceConfig.Builder("jdbc:mysql://192.168.33.21:3306/im-core", "root", "Abc_123456")
                        .dbQuery(new MySqlQuery())
                        .typeConvert(new MySqlTypeConvert())
                        .keyWordsHandler(new MySqlKeyWordsHandler())
                        .build();

        // 全局配置
        String projectPath = System.getProperty("user.dir");
        String rootPath = projectPath + "/scsi-basesaaa/bases-infraaaa";
        GlobalConfig globalConfig = new GlobalConfig.Builder()
                .fileOverride()
                .outputDir(rootPath + "/src/main/java")
                .author("Daniel Wang")
                .enableKotlin()
                .dateType(DateType.TIME_PACK)
                .commentDate("yyyy-MM-dd")
                .build();

        PackageConfig packageConfig = new PackageConfig.Builder()
                .parent(codePackage)
                .moduleName("sys")
                .entity("po")
                .service("service")
                .serviceImpl("service.impl")
                .mapper("mapper")
                .xml("mapper.xml")
                .controller("controller")
                .other("other")
                .pathInfo(Collections.singletonMap(OutputFile.mapperXml, "D://"))
                .build();

        TemplateConfig templateConfig1 = new TemplateConfig.Builder()

                .disable(TemplateType.ENTITY)
                .entity("/templates/entity.java")
                .service("/templates/service.java")
                .serviceImpl("/templates/serviceImpl.java")
                .mapper("/templates/mapper.java")
                .mapperXml("/resources/mapper.xml")
                .controller("/templates/controller.java")
                .build();

        StrategyConfig strategyConfig = new StrategyConfig.Builder()
                .addTablePrefix(tablePrefix)
                .addInclude(Arrays.asList(tables))
                .entityBuilder()
                .superClass(BaseEntity.class)
                .disableSerialVersionUID()
                .enableChainModel()
                .enableLombok()
                .enableRemoveIsPrefix()
                .enableTableFieldAnnotation()
                .enableActiveRecord()
                .superClass(BaseEntity.class)
//                .versionColumnName("version")
//                .versionPropertyName("version")
//                .logicDeleteColumnName("is_deleted")
//                .logicDeletePropertyName("deleteFlag")
                .naming(NamingStrategy.no_change)
                .columnNaming(NamingStrategy.underline_to_camel)
//                .addSuperEntityColumns("id", "created_time", "updated_time")
                .superClass(BaseEntity.class)
                .addIgnoreColumns("age")
//                .addTableFills(new Column("create_time", FieldFill.INSERT))
//                .addTableFills(new Property("updateTime", FieldFill.INSERT_UPDATE))
                .idType(IdType.AUTO)
                .formatFileName("%sEntity")
                .controllerBuilder()
//                .superClass(BaseController.class)
                .enableHyphenStyle()
                .enableRestStyle()
                .formatFileName("%sController")
                .serviceBuilder()
                .superServiceClass(BaseService.class)
                .superServiceImplClass(BaseServiceImpl.class)
                .formatServiceFileName("%sService")
                .formatServiceImplFileName("%sServiceImpl")
                .mapperBuilder()
                .superClass(BaseDao.class)
//                .enableMapperAnnotation()
                .enableBaseResultMap()
                .enableBaseColumnList()
//                .cache(MyMapperCache.class)
                .formatMapperFileName("%sDto")
                .formatXmlFileName("%sXml")
                .build();

        AutoGenerator mpg = new AutoGenerator(dataSourceConfig);
        mpg.global(globalConfig)
                .packageInfo(packageConfig)
                .template(templateConfig1)
                .strategy(strategyConfig);
        mpg.execute(new FreemarkerTemplateEngine());
//        FastAutoGenerator.create(url, username, password)
//                .globalConfig(builder -> {
//                    builder.author("abc") // 设置作者
//                            .enableSwagger() // 开启 swagger 模式
//                            .fileOverride() // 覆盖已生成文件
//                            .disableOpenDir() //禁止打开输出目录
//                            .outputDir(finalProjectPath + "/src/main/java"); // 指定输出目录
//                })
//                .packageConfig(builder -> {
//                    builder.parent("com.baomidou.mybatisplus.samples") // 设置父包名
//                            .moduleName("test") // 设置父包模块名
//                            .entity("model.entity") //设置entity包名
//                            .other("model.dto") // 设置dto包名
//                            .pathInfo(Collections.singletonMap(OutputFile.xml, finalProjectPath + "/src/main/resources/mapper")); // 设置mapperXml生成路径
//
//                })
//                .injectionConfig(consumer -> {
//                    Map<String, String> customFile = new HashMap<>();
//                    // DTO
//                    customFile.put("DTO.java", "/templates/entityDTO.java.ftl");
//                    consumer.customFile(customFile);
//                });

//        // 代码生成器
//        AutoGenerator mpg = new AutoGenerator();
//        // 全局配置
//        GlobalConfig gc = new GlobalConfig();
//        String projectPath = System.getProperty("user.dir");
//        String rootPath = projectPath + "/scsi-basesaaa/bases-infraaaa";
//
//        gc.setOutputDir(rootPath + "/src/main/java");
//        gc.setAuthor("JX");
//        gc.setOpen(true);
//        gc.setFileOverride(true);
//        gc.setBaseResultMap(true);
//        gc.setServiceName("%sService");// service 命名方式
//        gc.setMapperName("%sDao");
//        gc.setEntityName("%sEntity");
//        gc.setXmlName("%sDao");
//        mpg.setGlobalConfig(gc);
//
//        // 数据源配置
//        DataSourceConfig dsc = new DataSourceConfig();
//        // dsc.setUrl("jdbc:mysql://192.168.33.21:3306/base?useSSL=false");
//        dsc.setUrl("jdbc:mysql://10.1.100.160:3307/jx_base?useSSL=false");
//        dsc.setDriverName("com.mysql.jdbc.Driver");
//        dsc.setUsername("root");
//        dsc.setPassword("root");
//        dsc.setDbType(DbType.MYSQL);
//        dsc.setTypeConvert(ScisDbTypeConvert.INSTANCE);
//        mpg.setDataSource(dsc);
//
//        // 包配置
//        PackageConfig pc = new PackageConfig();
//        pc.setModuleName(String.format("%s", codePackage));
//        pc.setMapper("dao");
//        pc.setParent("com.jixiang");
//        mpg.setPackageInfo(pc);
//
//        // 自定义配置
//        InjectionConfig cfg = new InjectionConfig() {
//            @Override
//            public void initMap() {
//                // to do nothing
//            }
//        };
//
//        // 如果模板引擎是 freemarker
//        String templatePath = "/templates/mapper.xml.ftl";
//
//        String moduleName = pc.getModuleName();
//        String modulePath = moduleName.replace(".", File.separator);
//        // 自定义输出配置
//        List<FileOutConfig> focList = new ArrayList<>();
//        // 自定义配置会被优先输出
//        focList.add(new FileOutConfig(templatePath) {
//            @Override
//            public String outputFile(TableInfo tableInfo) {
//                // 自定义输出文件名 ， 如果你 Entity 设置了前后缀、此处注意 xml 的名称会跟着发生变化！！
//                String entityName = tableInfo.getEntityName();
//                String entityFileName = StrUtil.replace(entityName, "Entity", StringPool.EMPTY);
//                return rootPath + "/src/main/resources/mapper/" + modulePath + "/" + entityFileName + "Dao" + StringPool.DOT_XML;
//            }
//        });
//        cfg.setFileOutConfigList(focList);
//        mpg.setCfg(cfg);
//
//        // 配置模板
//        TemplateConfig templateConfig = new TemplateConfig();
//        // 不生成 Controller
//        templateConfig.disable(TemplateType.CONTROLLER, TemplateType.XML);
//        mpg.setTemplate(templateConfig);
//
//        // 策略配置
//        StrategyConfig strategy = new StrategyConfig();
//        strategy.setNaming(NamingStrategy.underline_to_camel);
//        strategy.setColumnNaming(NamingStrategy.underline_to_camel);
//        strategy.setCapitalMode(true);
//        strategy.setEntityLombokModel(true);
//        // strategy.setRestControllerStyle(false);
//        strategy.setInclude(tables);
//        strategy.setControllerMappingHyphenStyle(true);
//        strategy.setTablePrefix(tablePrefix);
//        strategy.setLogicDeleteFieldName("is_deleted");
//
//
//        mpg.setStrategy(strategy);
//        mpg.setTemplateEngine(new FreemarkerTemplateEngine());
//        mpg.execute();
    }

}
