package com.wb.imall.devools;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import com.wb.imall.common.base.BaseDao;
import com.wb.imall.common.base.BaseEntity;
import com.wb.imall.common.base.BaseService;
import com.wb.imall.common.base.BaseServiceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GeneratorMain {
    public static void main(String[] args) {
        List<String> tables = new ArrayList<>();
//        tables.add("im_friendship");
        tables.add("im_group");
        tables.add("im_group_member");
//        tables.add("p_answer");
//        tables.add("p_correct");

        FastAutoGenerator.create("jdbc:mysql://192.168.33.21:3306/im-core?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai"
                , "root"
                , "Abc_123456")
                .globalConfig(builder -> {
                    builder.author("Daniel Wang") // 设置类上注释作者
                            // 设置作者下的创建时间
                            .commentDate("yyyy-MM-dd")
//                            .enableSwagger() // 开启 swagger 模式
                            .fileOverride() // 覆盖已生成文件
                            .outputDir(System.getProperty("user.dir") + "\\src\\main\\java"); // 指定输出目录
                })
                .packageConfig(builder -> {
                    builder.parent("com.wb.imall.service")
                            // 模块包名
//                            .moduleName("demo")
                            .entity("entity")
                            .service("service")
                            .serviceImpl("service.Impl")
                            .controller("controller")
                            .mapper("mapper")
                            .xml("mapper")
                            .pathInfo(Collections.singletonMap(OutputFile.mapperXml, System.getProperty("user.dir") + "\\src\\main\\resources\\mapper"));
                })
                .strategyConfig(builder -> {
                    // 需要生成表的列表
                    builder.addInclude(tables)
                            // 过滤掉表的前缀去生成实体类
                            .addTablePrefix("im_")
                            // service策略配置
                            .serviceBuilder()
                            // 设置service类名，%s适配表名
                            .formatServiceFileName("%sService")
                            // 设置impl类名，%s适配表名
                            .formatServiceImplFileName("%sServiceImpl")
                            .superServiceClass(BaseService.class)
                            .superServiceImplClass(BaseServiceImpl.class)

                            // entity实体类策略配置
                            .entityBuilder()
                            .superClass(BaseEntity.class)
                            .addSuperEntityColumns("id", "version", "is_deleted", "creation_time", "update_time")
                            .formatFileName("%sEntity")
                            // 开启Lombok
//                            .enableLombok()
                            // 定义逻辑删除字段
//                            .logicDeleteColumnName("deleted")
                            // 属性上加说明注解
                            .enableTableFieldAnnotation()

                            // controller策略配置
                            .controllerBuilder()
                            // 设置controller类名，%s适配表名
                            .formatFileName("%sController")
                            // 开启RestController
                            .enableRestStyle()

                            // mapper策略配置
                            .mapperBuilder()
                            // 生成通用的resultMap
                            .enableBaseResultMap()
                            // 设置继承的父类
                            .superClass(BaseDao.class)
                            // 设置mapper类名，%s适配表名
                            .formatMapperFileName("%sDao")
                            // 开启@Mapper注解
                            .enableMapperAnnotation()
                            // 设置mapper的xml名，%s适配表名
                            .formatXmlFileName("%sDto");
                })
                // 使用Freemarker引擎模板，默认的是Velocity引擎模板
                .templateEngine(new FreemarkerTemplateEngine())
                .execute();

    }
}