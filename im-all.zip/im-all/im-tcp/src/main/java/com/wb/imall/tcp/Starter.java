package com.wb.imall.tcp;

import com.wb.imall.codec.config.IMConfig;
import com.wb.imall.tcp.server.TcpServer;
import com.wb.imall.tcp.server.WebsocketServer;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Starter {
    public static void main(String[] args) {
//        TcpServer ts = new TcpServer();
//        ts.start();
        IMConfig imConfig;
        try {
            imConfig = loadIMConfig();
            new TcpServer(imConfig.getIm()).start();
            new WebsocketServer(imConfig.getIm()).start();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static IMConfig loadIMConfig() throws FileNotFoundException {
        Yaml yaml = new Yaml();
        InputStream inputStream = new FileInputStream("E:\\develop\\learn\\im-all\\im-tcp\\src\\main\\resources\\config.yaml");
        IMConfig imConfig = yaml.loadAs(inputStream, IMConfig.class);
        System.out.println(imConfig);
        return imConfig;

    }
}
