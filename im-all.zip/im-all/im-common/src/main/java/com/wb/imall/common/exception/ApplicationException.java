package com.wb.imall.common.exception;

public class ApplicationException extends RuntimeException {

    private ApplicationExceptionEnum error;
    private String errMsg;

    public ApplicationException(ApplicationExceptionEnum exceptionEnum) {
        super(exceptionEnum.getError());
        this.errMsg = exceptionEnum.getError();
    }

    public ApplicationException(ApplicationExceptionEnum exceptionEnum, String errMsg) {
        super(exceptionEnum.getError());
        this.errMsg = errMsg;
    }

    public ApplicationExceptionEnum getErrorInfo() {
        return this.error;
    }

    public int getCode() {
        return error.getCode();
    }

    public String getError() {
        return error.getError();
    }

    public String getErrMsg() {
        return this.errMsg;
    }


    /**
     * avoid the expensive and useless stack trace for api exceptions
     *
     * @see Throwable#fillInStackTrace()
     */
    @Override
    public Throwable fillInStackTrace() {
        return this;
    }

}