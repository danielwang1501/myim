package com.wb.imall.common.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class AbstractRequest implements Serializable {
    private Integer appId;
    private Long operatorId;
}
