package com.wb.imall.common.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class RequestBase extends AbstractRequest {
    private Long id;
    private Integer version;
    private LocalDateTime creationTime;
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
