package com.wb.imall.common.base;

import com.baomidou.mybatisplus.annotation.*;
import com.wb.imall.common.base.typehandler.MillsUnixTimeDataTypeHandler;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Entity基础父类
 *
 * @author fitz.yang
 * @version 2020.12
 * @since triton 2020.12
 */
@Getter
@Setter
@Accessors(chain = true)
public abstract class BaseEntity implements Serializable {
    private static final long serialVersionUID = 7063326936118513230L;

    /**
     * 默认主键字段id，类型为Long型自增，转json时转换为String
     */
    @TableId(type = IdType.ASSIGN_ID)
    @TableField(updateStrategy = FieldStrategy.NEVER)
    private Long id;

    /**
     * app_id
     */
    @TableField("app_id")
    private Integer appId;

    /**
     * 数据库版本，用于乐观锁
     */
    @Version
    @TableField(value = "version", update = "%s+1")
    private Integer version;

    /**
     * 创建时间
     */
    @TableField(value = "creation_time", typeHandler = MillsUnixTimeDataTypeHandler.class, updateStrategy = FieldStrategy.NEVER)
    private LocalDateTime creationTime;

    /**
     * 修改时间
     */
    @TableField(value = "update_time", typeHandler = MillsUnixTimeDataTypeHandler.class)
    private LocalDateTime updateTime;

    /**
     * 删除标记 is_deleted=1 表示已删除
     */
    @TableField(value = "is_deleted", select = false)
    @TableLogic
    private Integer isDeleted;
}
