package com.wb.imall.common.util;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.wb.imall.common.base.BaseEntity;

public class WrapperUtil {
    public static <T extends BaseEntity> LambdaQueryWrapper<T> queryWithAppId(Class<T> t, Integer appId) {
        return Wrappers.lambdaQuery(t).eq(T::getAppId, appId);
    }

    public static <T extends BaseEntity> LambdaUpdateWrapper<T> updateWithAppId(Class<T> t, Integer appId) {
        return Wrappers.lambdaUpdate(t).eq(T::getAppId, appId);
    }
}
