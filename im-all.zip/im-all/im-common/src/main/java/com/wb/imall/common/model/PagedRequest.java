package com.wb.imall.common.model;

import lombok.Data;

@Data
public class PagedRequest extends AbstractRequest {
    private Long page = 1L;
    private Long limit = 10L;
}
