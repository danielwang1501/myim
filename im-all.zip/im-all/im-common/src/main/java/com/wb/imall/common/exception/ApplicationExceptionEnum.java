package com.wb.imall.common.exception;

public interface ApplicationExceptionEnum {

    int getCode();

    String getError();
}