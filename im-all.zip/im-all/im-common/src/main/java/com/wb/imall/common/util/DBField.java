package com.wb.imall.common.util;

public class DBField {
    public static String ID = "id";
    public static String APP_ID = "app_id";
}
