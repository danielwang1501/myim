package com.wb.imall.common.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public abstract class AbstractResponse {
    private Long id;
    private Integer appId;
    private Integer version;
    private LocalDateTime creationTime;
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
