package com.wb.imall.common.base;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wb.imall.common.util.DBField;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * 通用接口实现类
 *
 * @author fitz.yang
 * @version 2020.12
 * @since triton 2020.12
 */
@Slf4j
public class BaseServiceImpl<M extends BaseDao<T>, T extends BaseEntity> extends ServiceImpl<M, T> implements BaseService<T> {
//    @Override
//    @Transactional(readOnly = true, rollbackFor = Exception.class)
//    public Optional<T> unique(Serializable id) {
//        T entity = this.getById(id);
//        return Optional.ofNullable(entity);
//    }

    @Override
    public <A extends Serializable> List<T> getByIds(Integer appId, Collection<A> ids) {
        QueryWrapper<T> qw = new QueryWrapper<>();
        return this.list(qw.eq(DBField.APP_ID, appId).in(DBField.ID, ids));
    }

    @Override
    public Optional<T> unique(Integer appId, Long id) {
        QueryWrapper<T> qw = new QueryWrapper<>();
        T entity = this.getOne(qw.eq(DBField.APP_ID, appId).eq(DBField.ID, id));
        return Optional.ofNullable(entity);
    }

    @Override
    @Transactional(readOnly = true, rollbackFor = Exception.class)
    public Optional<T> unique(LambdaQueryWrapper<T> query) {
        query.last(" limit 1");
        T entity = this.getOne(query);
        return Optional.ofNullable(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean upldate(T entity) {
        if (Objects.isNull(entity.getAppId()) || Objects.isNull(entity.getId())) {
            throw new IllegalArgumentException("app_id is null or id is null");
        }
        entity.setUpdateTime(LocalDateTime.now());
        QueryWrapper<T> qw = new QueryWrapper<>();
        return this.update(entity, qw.eq(DBField.APP_ID, entity.getAppId()).eq(DBField.ID, entity.getId()));
        // return this.updateById(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean upldate(LambdaUpdateWrapper<T> updateWrapper) {
        updateWrapper.set(T::getUpdateTime, LocalDateTime.now());
        return this.update(updateWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean insert(T entity) {
        entity.setCreationTime(LocalDateTime.now());
        return this.save(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveOrUpdate(T entity, Serializable unionId) {
        if (Objects.nonNull(unionId)) {
            return this.insert(entity);
        }
        return this.upldate(entity);
    }


    //    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public void upldateByCode(T entity, String code) {
//        entity.setUpdateTime(LocalDateTime.now());
//        this.update(entity, new QueryWrapper<T>().eq("code", code));
//    }
//
//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public T getlByCode(String code) {
//        return this.getOne(new QueryWrapper<T>().eq("code", code));
//    }
//
//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public List<T> getlByCodes(List<String> codes) {
//        return this.list(new QueryWrapper<T>().in("code", codes));
//    }
//
//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public void removeByIds(List<Long> ids) {
//        this.remove(new LambdaQueryWrapper<T>().in(T::getId, ids));
//    }
//
//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public void removeById(Long id) {
//        this.remove(new LambdaQueryWrapper<T>().eq(T::getId, id));
//    }
}
