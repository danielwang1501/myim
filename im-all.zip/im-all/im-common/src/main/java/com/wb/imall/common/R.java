package com.wb.imall.common;

import com.wb.imall.common.exception.ApplicationExceptionEnum;
import com.wb.imall.common.exception.BasisCode;
import lombok.Data;

@Data
public class R<T> {

    private int code;

    private String msg;

    private T data;

    private Long total;

    public static R ok(Object data) {
        return ok(data, null);
    }

    public static R ok(Object data, Long total) {
        return new R(BasisCode.SUCESS, data);
    }

    public static R ok() {
        return ok(null);
    }

    public static R error() {
        return R.error(BasisCode.SERVER_ERROR, null);
    }

    public static <T> R error(T data) {
        return R.error(data, BasisCode.SERVER_ERROR);
    }

    public static R error(ApplicationExceptionEnum enums) {
        return new R(enums.getCode(), enums.getError());
    }

    public static <T> R error(T data, ApplicationExceptionEnum enums) {
        return new R(enums.getCode(), enums.getError(), data);
    }

    public R msg(String msg) {
        this.msg = msg;
        return this;
    }

    public boolean isOk() {
        return this.code == BasisCode.SUCESS.getCode();
    }

    public R(int code, String msg) {
        this(code, msg, null);
    }

    public R(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public R(ApplicationExceptionEnum exceptionEnum, T data) {
        this(exceptionEnum, data, null);
    }

    public R(ApplicationExceptionEnum exceptionEnum, T data, Long total) {
        this.code = exceptionEnum.getCode();
        this.msg = exceptionEnum.getError();
        this.data = data;
        this.total = total;
    }

}